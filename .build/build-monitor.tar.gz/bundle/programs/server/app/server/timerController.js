(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/timerController.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by imod on 5/8/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
                                                                       //
// TODO: This won't work too well if we have multiple server instances.
// TODO: Add a configuration option to indicate if this is the main server instance, or...
// TODO: Create a second server only app / node server that just the timers.
                                                                       //
var RUNNING_BUILD_QUERY_MS = 20000,                                    // 12
    CURRENT_BUILD_STATUS_QUERY_MS = 5000;                              //
                                                                       //
Controllers.Timer = (function () {                                     // 15
	var buildQueryHandle = false,                                         // 16
	    currentBuildServerTimerHandles = [];                              //
                                                                       //
	function StartRunningBuildsTimer(serverId) {                          // 19
		if (!process.env.IS_MIRROR) {                                        // 20
			console.log('Starting running build timer for server: ' + serverId);
                                                                       //
			var id = Meteor.setInterval(function () {                           // 23
				Controllers.Timer.onRunningBuildQueryInterval(serverId);           // 24
			}, CURRENT_BUILD_STATUS_QUERY_MS);                                  //
                                                                       //
			currentBuildServerTimerHandles.push({ serverId: serverId, timerId: id });
		}                                                                    //
	}                                                                     //
                                                                       //
	function StopRunningBuildsTimer(serverId) {                           // 31
		console.log('Stopping running build timer for server: ' + serverId);
		var serverTimerHandle = _.find(currentBuildServerTimerHandles, function (s) {
			return s.serverId === serverId;                                     // 34
		});                                                                  //
                                                                       //
		Meteor.clearInterval(serverTimerHandle.timerId);                     // 37
		currentBuildServerTimerHandles = _.reject(currentBuildServerTimerHandles, function (s) {
			return s.serverId === serverTimerHandle.serverId;                   // 39
		});                                                                  //
	}                                                                     //
                                                                       //
	function CheckRunningBuildsTimer(serverId, hasActiveBuilds) {         // 43
		var serverTimerHandle = _.find(currentBuildServerTimerHandles, function (s) {
			return s.serverId === serverId;                                     // 45
		});                                                                  //
                                                                       //
		if (hasActiveBuilds && !serverTimerHandle) {                         // 48
			Controllers.Timer.onStartRunningBuildsTimer(serverId);              // 49
		} else if (!hasActiveBuilds && serverTimerHandle) {                  //
			Controllers.Timer.onStopRunningBuildsTimer(serverId);               // 51
		}                                                                    //
	}                                                                     //
                                                                       //
	/**                                                                   //
  * This will be called every CURRENT_BUILD_STATUS_QUERY_MS to update the status
  * of the running builds.                                             //
  *                                                                    //
  * @param serverId                                                    //
  * @constructor                                                       //
  */                                                                   //
	function RunningBuildQueryInterval(serverId) {                        // 63
		console.log('Running build timer for server: ' + serverId);          // 64
                                                                       //
		var server = Controllers.Servers.getServer(serverId);                // 66
		server.updateRunningBuilds(CheckRunningBuildsTimer);                 // 67
	}                                                                     //
                                                                       //
	function PollInterval() {                                             // 70
		var servers = Controllers.Servers.getServers();                      // 71
		servers.forEach(function (server) {                                  // 72
			server.queryRunningBuilds(CheckRunningBuildsTimer);                 // 73
		});                                                                  //
	}                                                                     //
                                                                       //
	function Startup() {                                                  // 77
		if (buildQueryHandle !== false) {                                    // 78
			Meteor.clearTimeout(buildQueryHandle);                              // 79
			buildQueryHandle = false;                                           // 80
		}                                                                    //
                                                                       //
		if (!process.env.IS_MIRROR) {                                        // 83
			buildQueryHandle = Meteor.setInterval(PollInterval, RUNNING_BUILD_QUERY_MS);
		}                                                                    //
	}                                                                     //
                                                                       //
	return {                                                              // 88
		onStartUp: Startup,                                                  // 89
		onStartRunningBuildsTimer: StartRunningBuildsTimer,                  // 90
		onStopRunningBuildsTimer: StopRunningBuildsTimer,                    // 91
		onRunningBuildQueryInterval: RunningBuildQueryInterval,              // 92
		onCheckRunningBuildsTimer: CheckRunningBuildsTimer,                  // 93
		onPollInterval: PollInterval                                         // 94
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=timerController.js.map
