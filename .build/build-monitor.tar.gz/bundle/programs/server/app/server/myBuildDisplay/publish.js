(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/myBuildDisplay/publish.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
Meteor.publish('myBuildDisplay', function () {                         // 2
	// TODO: Need to configure this to only show displayed when on dashboard.
	return Collections.MyBuildDisplay.find({ userId: this.userId });      // 4
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
