(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/myBuildDisplay/myBuildDisplay.js                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
Controllers.MyBuildDisplayAllow = (function () {                       // 2
	function Insert(userId, doc) {                                        // 3
		return userId === Meteor.userId();                                   // 4
	}                                                                     //
                                                                       //
	function Update(userId, doc, fieldNames, modifier) {                  // 7
		return userId === Meteor.userId();                                   // 8
	}                                                                     //
                                                                       //
	return {                                                              // 11
		onInsert: Insert,                                                    // 12
		onUpdate: Update                                                     // 13
	};                                                                    //
})();                                                                  //
                                                                       //
Collections.MyBuildDisplay.allow({                                     // 17
	insert: Controllers.MyBuildDisplayAllow.onInsert,                     // 18
	update: Controllers.MyBuildDisplayAllow.onUpdate,                     // 19
                                                                       //
	remove: function () {                                                 // 21
		return false;                                                        // 22
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=myBuildDisplay.js.map
