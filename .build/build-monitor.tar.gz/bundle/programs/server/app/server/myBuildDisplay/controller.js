(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/myBuildDisplay/controller.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
Controllers.MyBuildDisplay = (function () {                            // 2
	function GetBuildDisplayCount(buildId) {                              // 3
		return Collections.Builds.find({ _id: buildId }, { fields: { _id: 1 } }).count();
	}                                                                     //
                                                                       //
	function RemoveByBuildId(buildId) {                                   // 7
		Collections.MyBuildDisplay.remove({ buildId: buildId });             // 8
	}                                                                     //
                                                                       //
	return {                                                              // 11
		onGetBuildDisplayCount: GetBuildDisplayCount,                        // 12
		onRemoveByBuildId: RemoveByBuildId                                   // 13
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=controller.js.map
