(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/users/controller.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/23/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Controllers.Users = (function () {                                     // 6
	function CreateUser(options, user) {                                  // 7
		if (!options || !user || !options.email) {                           // 8
			throw new Meteor.Error(500, 'Invalid input!');                      // 9
		}                                                                    //
                                                                       //
		if (!Meteor.users.findOne()) {                                       // 12
			user.isAdmin = true;                                                // 13
		}                                                                    //
                                                                       //
		if (!user.isAdmin) {                                                 // 16
			if (Meteor.users.findOne({ 'emails.0.address': options.email })) {  // 17
				throw new Meteor.Error(500, 'Email already exists');               // 18
			}                                                                   //
		}                                                                    //
                                                                       //
		return user;                                                         // 22
	}                                                                     //
                                                                       //
	return {                                                              // 25
		onCreateUser: CreateUser                                             // 26
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=controller.js.map
