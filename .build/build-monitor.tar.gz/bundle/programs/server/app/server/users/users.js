(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/users/users.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/23/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Meteor.users.allow({                                                   // 6
	insert: function () {                                                 // 7
		return false;                                                        // 8
	},                                                                    //
                                                                       //
	update: function () {                                                 // 11
		return false;                                                        // 12
	},                                                                    //
	remove: function () {                                                 // 14
		return false;                                                        // 15
	}                                                                     //
});                                                                    //
                                                                       //
Accounts.onCreateUser(Controllers.Users.onCreateUser);                 // 19
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=users.js.map
