(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/users/publish.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by imod on 4/24/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Meteor.publish('myUser', function () {                                 // 6
  return Meteor.users.find({ _id: this.userId }, { fields: { isAdmin: 1, username: 1, profile: 1 } });
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
