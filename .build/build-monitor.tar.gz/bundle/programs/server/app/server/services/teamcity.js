(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/services/teamcity.js                                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
                                                                       //
Services.TeamCity = function (server, isTest) {                        // 3
	this.server = server;                                                 // 4
	this.isTest = isTest === true;                                        // 5
};                                                                     //
                                                                       //
Services.TeamCity.prototype = {                                        // 8
	//region Properties                                                   //
	get hasAuth() {                                                       // 10
		if (!this.server.user || !this.server.password) {                    // 11
			return false;                                                       // 12
		}                                                                    //
                                                                       //
		return true;                                                         // 15
	},                                                                    //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	_buildOptions: function () {                                          // 20
		var opt = {                                                          // 21
			timeOut: 30000,                                                     // 22
			headers: {                                                          // 23
				'Accept': 'application/json'                                       // 24
			}                                                                   //
		};                                                                   //
                                                                       //
		if (this.hasAuth) {                                                  // 28
			opt.auth = this.server.user + ':' + this.server.password;           // 29
		}                                                                    //
                                                                       //
		return opt;                                                          // 32
	},                                                                    //
                                                                       //
	_call: function (url, callback) {                                     // 35
		var opt = this._buildOptions(),                                      // 36
		    fullUrl = this.server.url;                                       //
                                                                       //
		if (url.indexOf('/httpAuth/') === -1 && url.indexOf('/guestAuth/') === -1) {
			if (this.hasAuth) {                                                 // 40
				fullUrl += '/httpAuth';                                            // 41
			} else {                                                            //
				fullUrl += '/guestAuth';                                           // 43
			}                                                                   //
		}                                                                    //
                                                                       //
		fullUrl += url;                                                      // 47
                                                                       //
		console.log('Calling: ' + fullUrl);                                  // 49
		HTTP.get(fullUrl, opt, function (err, response) {                    // 50
			if (err) {                                                          // 51
				throw err;                                                         // 52
			}                                                                   //
                                                                       //
			if (response.statusCode !== 200) {                                  // 55
				throw 'Call was not successful. Status code: ' + response.statusCode;
			}                                                                   //
                                                                       //
			callback(response.data);                                            // 59
		});                                                                  //
	},                                                                    //
                                                                       //
	_tcDateTimeToDate: function (datetime) {                              // 63
		if (!datetime) {                                                     // 64
			return null;                                                        // 65
		}                                                                    //
		return moment(datetime, 'YYYYMMDDTHHmmssZ').toDate();                // 67
	},                                                                    //
                                                                       //
	/**                                                                   //
  * If a build was auto-triggered because of a dependency, this will try to get that dependency detail.
  *                                                                    //
  * @param buildDetail                                                 //
  * @param cb                                                          //
  * @returns {*}                                                       //
  * @private                                                           //
  */                                                                   //
	_getDependencyBuildDetails: function (buildDetail, cb) {              // 78
		var self = this,                                                     // 79
		    snapshot = buildDetail['snapshot-dependencies'],                 //
		    artifact = buildDetail['artifact-dependencies'],                 //
		    href = false;                                                    //
		if (snapshot && snapshot.count > 0) {                                // 83
			href = snapshot.build[0].href;                                      // 84
		} else if (artifact && artifact.count > 0) {                         //
			href = artifact.build[0].href;                                      // 86
		}                                                                    //
		if (!href) {                                                         // 88
			return self._createBuildDetails(buildDetail, [], cb);               // 89
		}                                                                    //
                                                                       //
		self._call(href, function (depDetail) {                              // 92
			var users = self._getUsersFromBuildDetail(depDetail);               // 93
			self._createBuildDetails(buildDetail, users, cb);                   // 94
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Builds the BuildDetails object and sends it to the callback.       //
  *                                                                    //
  * @param buildDetail                                                 //
  * @param users                                                       //
  * @param cb                                                          //
  * @private                                                           //
  */                                                                   //
	_createBuildDetails: function (buildDetail, users, cb) {              // 106
		var self = this;                                                     // 107
                                                                       //
		var bh = new Models.BuildDetail({                                    // 109
			id: buildDetail.id,                                                 // 110
			serviceBuildId: buildDetail.buildTypeId,                            // 111
			serviceNumber: buildDetail.number,                                  // 112
			isSuccess: buildDetail.status === 'SUCCESS',                        // 113
			isBuilding: buildDetail.running === true,                           // 114
			href: buildDetail.href,                                             // 115
			percentageComplete: buildDetail.percentageComplete,                 // 116
			statusText: buildDetail.statusText,                                 // 117
			startDate: self._tcDateTimeToDate(buildDetail.startDate),           // 118
			finishDate: self._tcDateTimeToDate(buildDetail.finishDate),         // 119
			usernames: users                                                    // 120
		});                                                                  //
                                                                       //
		cb(bh);                                                              // 123
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Gets the responsible user from a build detail.                     //
  *                                                                    //
  * @param buildDetail                                                 //
  * @returns {Array}                                                   //
  * @private                                                           //
  */                                                                   //
	_getUsersFromBuildDetail: function (buildDetail) {                    // 133
		var users = [];                                                      // 134
		if (buildDetail.triggered) {                                         // 135
			switch (buildDetail.triggered.type) {                               // 136
				case 'buildType':                                                  // 137
				case 'user':                                                       // 138
					{                                                                 // 139
						users = [buildDetail.triggered.user.username];                   // 140
					}break;                                                           //
                                                                       //
				case 'vcs':                                                        // 141
					{                                                                 // 144
						if (buildDetail.lastChanges.count > 0) {                         // 145
							users = _.map(buildDetail.lastChanges.change, function (change) {
								return change.username;                                        // 147
							});                                                             //
						}                                                                //
					}break;                                                           //
			}                                                                   // 150
		}                                                                    //
                                                                       //
		return users;                                                        // 154
	},                                                                    //
                                                                       //
	getBuildData: function (href, historyCount, cb) {                     // 157
		var self = this;                                                     // 158
                                                                       //
		self._call(href + '/builds?count=' + historyCount, function (data) {
			var bhArray = [],                                                   // 161
			    expectedCount = data.count;                                     //
                                                                       //
			for (var i = 0; i < expectedCount; i++) {                           // 164
				var build = data.build[i];                                         // 165
                                                                       //
				self.getBuildDetails(build.href, function (bh) {                   // 167
					bhArray.push(bh);                                                 // 168
                                                                       //
					if (bhArray.length === expectedCount) {                           // 170
						bhArray = _.sortBy(bhArray, function (item) {                    // 171
							return item.id;                                                 // 171
						}).reverse();                                                    //
						cb(bhArray);                                                     // 172
					}                                                                 //
				});                                                                //
			}                                                                   //
		});                                                                  //
	},                                                                    //
                                                                       //
	getBuildDetails: function (href, cb) {                                // 179
		var self = this;                                                     // 180
		self._call(href, function (buildDetail) {                            // 181
			if (buildDetail.triggered && buildDetail.triggered.type === 'unknown') {
				return self._getDependencyBuildDetails(buildDetail, cb);           // 183
			}                                                                   //
                                                                       //
			var users = self._getUsersFromBuildDetail(buildDetail);             // 186
			self._createBuildDetails(buildDetail, users, cb);                   // 187
		});                                                                  //
	},                                                                    //
                                                                       //
	queryRunningBuilds: function (cb) {                                   // 191
		var self = this;                                                     // 192
		self._call('/app/rest/builds?locator=running:true', function (buildSummary) {
			var bsArr = [];                                                     // 194
                                                                       //
			if (buildSummary.count === 0) {                                     // 196
				return cb(bsArr);                                                  // 197
			}                                                                   //
                                                                       //
			buildSummary.build.forEach(function (build) {                       // 200
				bsArr.push(new Models.BuildSummary({                               // 201
					id: build.id,                                                     // 202
					serviceBuildId: build.buildTypeId,                                // 203
					serviceNumber: build.number,                                      // 204
					isSuccess: build.status === 'SUCCESS',                            // 205
					isBuilding: build.running === true,                               // 206
					href: build.href                                                  // 207
				}));                                                               //
			});                                                                 //
                                                                       //
			cb(bsArr);                                                          // 212
		});                                                                  //
	},                                                                    //
                                                                       //
	getProjects: function (cb) {                                          // 216
		var self = this;                                                     // 217
                                                                       //
		self._call('/app/rest/projects', function (tcProjects) {             // 219
			if (!tcProjects) {                                                  // 220
				return;                                                            // 221
			}                                                                   //
                                                                       //
			for (var i = 0; i < tcProjects.count; i++) {                        // 224
				var project = tcProjects.project[i];                               // 225
                                                                       //
				if (project.id === '_Root') {                                      // 227
					continue;                                                         // 228
				}                                                                  //
                                                                       //
				self._call(project.href, function (tcProject) {                    // 231
					var proj = new Models.Project({                                   // 232
						serverId: self.server._id,                                       // 233
						serviceProjectId: tcProject.id,                                  // 234
						serviceParentProjectId: tcProject.parentProjectId === '_Root' ? null : tcProject.parentProjectId,
						name: tcProject.name,                                            // 236
						href: tcProject.href                                             // 237
					}),                                                               //
					    builds = [];                                                  //
                                                                       //
					if (tcProject.buildTypes && tcProject.buildTypes.count > 0) {     // 241
						for (var ib = 0; ib < tcProject.buildTypes.count; ib++) {        // 242
							var b = tcProject.buildTypes.buildType[ib],                     // 243
							    build = new Models.Build({                                  //
								serverId: self.server._id,                                     // 245
								serviceProjectId: b.projectId,                                 // 246
								serviceBuildId: b.id,                                          // 247
								name: b.name,                                                  // 248
								href: b.href                                                   // 249
							});                                                             //
                                                                       //
							builds.push(build);                                             // 252
						}                                                                //
					}                                                                 //
                                                                       //
					cb(proj, builds);                                                 // 256
				});                                                                //
			}                                                                   //
		});                                                                  //
	}                                                                     //
                                                                       //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=teamcity.js.map
