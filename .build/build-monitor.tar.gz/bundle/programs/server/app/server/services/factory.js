(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/services/factory.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/26/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Services.Factory = (function () {                                      // 6
	function GetService(server) {                                         // 7
		switch (server.type) {                                               // 8
			case 'teamcity':                                                    // 9
				{                                                                  // 9
					return new Services.TeamCity(server, false /*s(server.url).contains('example.com')*/);
				}break;                                                            //
                                                                       //
			default:                                                            // 13
				{                                                                  // 13
					throw 'Invalid server type: ' + server.type;                      // 14
				}                                                                  //
		}                                                                    // 15
	}                                                                     //
                                                                       //
	return {                                                              // 19
		getService: GetService                                               // 20
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=factory.js.map
