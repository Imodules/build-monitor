(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/main.js                                                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
Controllers.main = (function () {                                      // 2
                                                                       //
	function RefreshActiveBuilds() {                                      // 4
		var servers = Controllers.Servers.getServers();                      // 5
                                                                       //
		servers.forEach(function (server) {                                  // 7
			server.refreshActiveBuildData();                                    // 8
		});                                                                  //
	}                                                                     //
                                                                       //
	return {                                                              // 12
		onRefreshActiveBuilds: RefreshActiveBuilds                           // 13
	};                                                                    //
})();                                                                  //
                                                                       //
Meteor.startup(function () {                                           // 17
	Controllers.main.onRefreshActiveBuilds();                             // 18
	Controllers.Timer.onStartUp();                                        // 19
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=main.js.map
