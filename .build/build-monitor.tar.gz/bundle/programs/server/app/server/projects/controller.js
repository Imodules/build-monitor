(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/projects/controller.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/24/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Controllers.Projects = (function () {                                  // 6
	function _transform(doc) {                                            // 7
		return new Models.Project(doc);                                      // 8
	}                                                                     //
                                                                       //
	function GetAllByServerId(serverId) {                                 // 11
		return Collections.Projects.find({ serverId: serverId }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetByServiceProjectId(serverId, serviceProjectId) {          // 15
		return Collections.Projects.findOne({ serverId: serverId, serviceProjectId: serviceProjectId }, { transform: _transform });
	}                                                                     //
                                                                       //
	/**                                                                   //
  * @param {Models.Build} build                                        //
  * @returns {*}                                                       //
  * @constructor                                                       //
  */                                                                   //
	function AddBuild(build) {                                            // 24
		return Collections.Builds.upsert({                                   // 25
			serverId: build.serverId,                                           // 26
			projectId: build.projectId,                                         // 27
			serviceBuildId: build.serviceBuildId                                // 28
		}, {                                                                 //
			$set: {                                                             // 30
				name: build.name,                                                  // 31
				href: build.href                                                   // 32
			}                                                                   //
		});                                                                  //
	}                                                                     //
                                                                       //
	/**                                                                   //
  *                                                                    //
  * @param {Models.Project} project                                    //
  * @param {Models.Build} builds[]                                     //
  * @returns {*}                                                       //
  * @constructor                                                       //
  */                                                                   //
	function AddProject(project, builds) {                                // 44
		var parentId = null;                                                 // 45
		if (project.serviceParentProjectId) {                                // 46
			var parentProject = Controllers.Projects.getByServiceProjectId(project.serverId, project.serviceParentProjectId);
			if (parentProject) {                                                // 48
				parentId = parentProject._id;                                      // 49
			}                                                                   //
		}                                                                    //
                                                                       //
		Collections.Projects.upsert({                                        // 53
			serverId: project.serverId,                                         // 54
			serviceProjectId: project.serviceProjectId                          // 55
		}, {                                                                 //
			$set: {                                                             // 57
				serviceParentProjectId: project.serviceParentProjectId,            // 58
				parentId: parentId,                                                // 59
				name: project.name,                                                // 60
				href: project.href                                                 // 61
			}                                                                   //
		});                                                                  //
                                                                       //
		var existingProj = Controllers.Projects.getByServiceProjectId(project.serverId, project.serviceProjectId);
                                                                       //
		builds.forEach(function (build) {                                    // 67
			build.projectId = existingProj._id;                                 // 68
			AddBuild(build);                                                    // 69
		});                                                                  //
	}                                                                     //
                                                                       //
	function RemoveByServerId(serverId) {                                 // 73
		Collections.Projects.remove({ serverId: serverId });                 // 74
	}                                                                     //
                                                                       //
	return {                                                              // 77
		getAllByServerId: GetAllByServerId,                                  // 78
		getByServiceProjectId: GetByServiceProjectId,                        // 79
		onAddProject: AddProject,                                            // 80
		onRemoveByServerId: RemoveByServerId                                 // 81
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=controller.js.map
