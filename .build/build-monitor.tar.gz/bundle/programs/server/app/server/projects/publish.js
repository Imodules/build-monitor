(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/projects/publish.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by imod on 4/28/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Meteor.publish('projects', function () {                               // 6
  return Collections.Projects.find({});                                // 7
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
