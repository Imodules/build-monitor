(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/builds/builds.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by imod on 4/29/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Collections.Builds.allow({                                             // 6
	insert: function () {                                                 // 7
		return false;                                                        // 8
	},                                                                    //
                                                                       //
	update: function (userId, doc, fieldNames, modifier) {                // 11
		return false;                                                        // 12
	},                                                                    //
	remove: function () {                                                 // 14
		return false;                                                        // 15
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=builds.js.map
