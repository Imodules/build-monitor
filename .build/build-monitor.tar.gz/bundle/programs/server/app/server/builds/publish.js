(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/builds/publish.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by imod on 4/29/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
                                                                       //
Meteor.publish('builds', function () {                                 // 7
  return Collections.Builds.find();                                    // 8
});                                                                    //
                                                                       //
Meteor.publish('displayedBuilds', function () {                        // 11
  return Collections.Builds.find({ watchers: { $in: [this.userId] } });
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
