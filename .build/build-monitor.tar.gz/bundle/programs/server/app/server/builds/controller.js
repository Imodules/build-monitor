(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/builds/controller.js                                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/1/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Controllers.Builds = (function () {                                    // 6
                                                                       //
	//region Private                                                      //
	function _transform(doc) {                                            // 9
		return new Models.Build(doc);                                        // 10
	}                                                                     //
                                                                       //
	//endregion                                                           //
                                                                       //
	function GetBuild(buildId) {                                          // 15
		return Collections.Builds.findOne({ _id: buildId }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetActiveServerBuilds(serverId) {                            // 19
		return Collections.Builds.find({ serverId: serverId, watcherCount: { $gt: 0 } }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetBuildByServiceId(serverId, serviceBuildId) {              // 26
		return Collections.Builds.findOne({ serverId: serverId, serviceBuildId: serviceBuildId }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetRunningServerBuilds(serverId) {                           // 33
		return Collections.Builds.find({ serverId: serverId, isBuilding: true }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetAllByProjectId(projectId) {                               // 40
		return Collections.Builds.find({ projectId: projectId }, { transform: _transform });
	}                                                                     //
                                                                       //
	function RemoveByServerId(serverId) {                                 // 44
		var builds = Collections.Builds.find({ serverId: serverId }, { fields: { _id: 1 } }).fetch();
                                                                       //
		builds.forEach(function (build) {                                    // 47
			Controllers.MyBuildDisplay.onRemoveByBuildId(build._id);            // 48
		});                                                                  //
                                                                       //
		console.log('Removing Builds');                                      // 51
		Collections.Builds.remove({ serverId: serverId });                   // 52
	}                                                                     //
                                                                       //
	return {                                                              // 55
		getBuild: GetBuild,                                                  // 56
		getActiveServerBuilds: GetActiveServerBuilds,                        // 57
		getBuildByServiceId: GetBuildByServiceId,                            // 58
		getRunningServerBuilds: GetRunningServerBuilds,                      // 59
                                                                       //
		getAllByProjectId: GetAllByProjectId,                                // 61
                                                                       //
		onRemoveByServerId: RemoveByServerId                                 // 63
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=controller.js.map
