(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/servers/publish.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/23/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Meteor.publish('servers', function () {                                // 6
	var user = Meteor.users.findOne({ _id: this.userId }, { fields: { isAdmin: 1 } });
                                                                       //
	if (!user || !user.isAdmin) {                                         // 9
		return this.ready();                                                 // 10
	}                                                                     //
                                                                       //
	return Collections.Servers.find({});                                  // 13
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
