(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/servers/servers.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 4/23/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Collections.Servers.allow({                                            // 6
	insert: function () {                                                 // 7
		return false;                                                        // 8
	},                                                                    //
	update: function () {                                                 // 10
		return false;                                                        // 11
	},                                                                    //
	remove: function () {                                                 // 13
		return false;                                                        // 14
	}                                                                     //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 18
	insertServer: Controllers.Servers.onSaveServer,                       // 19
	updateServer: Controllers.Servers.onSaveServer,                       // 20
	deleteServer: Controllers.Servers.onDeleteServer,                     // 21
                                                                       //
	refreshProjects: Controllers.Servers.onRefreshProjects,               // 23
	watchBuild: Controllers.Servers.onWatchBuild                          // 24
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=servers.js.map
