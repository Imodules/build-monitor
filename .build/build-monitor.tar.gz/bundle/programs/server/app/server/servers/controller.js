(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/servers/controller.js                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
'use strict';                                                          // 1
Controllers.Servers = (function () {                                   // 2
	function _validateUser() {                                            // 3
		if (!Meteor.user().isAdmin) {                                        // 4
			throw new Meteor.Error(403, 'You are not authorized for this change.');
		}                                                                    //
                                                                       //
		return true;                                                         // 8
	}                                                                     //
                                                                       //
	function _cleanUnamePWord(uname, pword) {                             // 11
		var user = s.isBlank(uname) ? false : uname,                         // 12
		    password = s.isBlank(pword) ? false : pword;                     //
                                                                       //
		return { user: user, password: password };                           // 15
	}                                                                     //
                                                                       //
	function _transform(doc) {                                            // 18
		return new Models.Server(doc);                                       // 19
	}                                                                     //
                                                                       //
	function GetServer(serverId) {                                        // 22
		return Collections.Servers.findOne({ _id: serverId }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetServerByName(name) {                                      // 26
		return Collections.Servers.findOne({ name: name }, { transform: _transform });
	}                                                                     //
                                                                       //
	function GetServers() {                                               // 30
		return Collections.Servers.find({}, { transform: _transform });      // 31
	}                                                                     //
                                                                       //
	function SaveServer(id, name, url, uname, pword) {                    // 34
		_validateUser();                                                     // 35
                                                                       //
		if (!name || !url) {                                                 // 37
			throw new Meteor.Error(500, 'Missing required field');              // 38
		}                                                                    //
                                                                       //
		var up = _cleanUnamePWord(uname, pword);                             // 41
                                                                       //
		var server = new Models.Server({                                     // 43
			_id: id,                                                            // 44
			name: name,                                                         // 45
			type: 'teamcity',                                                   // 46
			url: url,                                                           // 47
			user: up.user,                                                      // 48
			password: up.password                                               // 49
		});                                                                  //
		return server.save();                                                // 51
	}                                                                     //
                                                                       //
	function DeleteServer(id) {                                           // 54
		_validateUser();                                                     // 55
                                                                       //
		Controllers.Projects.onRemoveByServerId(id);                         // 57
		Controllers.Builds.onRemoveByServerId(id);                           // 58
		Collections.Servers.remove({ _id: id });                             // 59
	}                                                                     //
                                                                       //
	/**                                                                   //
  * @return {boolean}                                                  //
  */                                                                   //
	function RefreshProjects(serverId) {                                  // 65
		console.log('Refreshing projects: ' + serverId);                     // 66
		var server = Controllers.Servers.getServer(serverId);                // 67
		server.refreshProjects();                                            // 68
	}                                                                     //
                                                                       //
	function WatchBuild(serverId, buildId, userId, isWatch) {             // 71
		var server = Controllers.Servers.getServer(serverId);                // 72
		server.toggleBuildDisplay(buildId, userId, isWatch);                 // 73
	}                                                                     //
                                                                       //
	return {                                                              // 76
		getServer: GetServer,                                                // 77
		getServerByName: GetServerByName,                                    // 78
		getServers: GetServers,                                              // 79
                                                                       //
		onSaveServer: SaveServer,                                            // 81
		onDeleteServer: DeleteServer,                                        // 82
		onRefreshProjects: RefreshProjects,                                  // 83
                                                                       //
		onWatchBuild: WatchBuild                                             // 85
	};                                                                    //
})();                                                                  //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=controller.js.map
