(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/server.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/7/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Models.Server = function (doc) {                                       // 6
	this._doc = doc;                                                      // 7
	this._service = Services.Factory.getService(this._doc);               // 8
};                                                                     //
                                                                       //
Models.Server.prototype = {                                            // 11
	//region Properties                                                   //
	get service() {                                                       // 13
		return this._service;                                                // 14
	},                                                                    //
                                                                       //
	get _id() {                                                           // 17
		return this._doc._id;                                                // 18
	},                                                                    //
                                                                       //
	get name() {                                                          // 21
		return this._doc.name;                                               // 22
	},                                                                    //
	set name(value) {                                                     // 24
		this._doc.name = value;                                              // 25
	},                                                                    //
                                                                       //
	get type() {                                                          // 28
		return this._doc.type;                                               // 29
	},                                                                    //
	set type(value) {                                                     // 31
		this._doc.type = value;                                              // 32
	},                                                                    //
                                                                       //
	get url() {                                                           // 35
		return this._doc.url;                                                // 36
	},                                                                    //
	set url(value) {                                                      // 38
		this._doc.url = value;                                               // 39
	},                                                                    //
                                                                       //
	get user() {                                                          // 42
		return this._doc.user;                                               // 43
	},                                                                    //
	set user(value) {                                                     // 45
		this._doc.user = value;                                              // 46
	},                                                                    //
                                                                       //
	get password() {                                                      // 49
		return this._doc.password;                                           // 50
	},                                                                    //
	set password(value) {                                                 // 52
		this._doc.password = value;                                          // 53
	},                                                                    //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	toJson: function () {                                                 // 58
		return this._doc;                                                    // 59
	},                                                                    //
                                                                       //
	save: function (cb) {                                                 // 62
		var updData = {                                                      // 63
			name: this.name,                                                    // 64
			type: 'teamcity',                                                   // 65
			url: this.url,                                                      // 66
			user: this.user,                                                    // 67
			password: this.password                                             // 68
		};                                                                   //
                                                                       //
		if (this._id) {                                                      // 71
			return Collections.Servers.update({ _id: this._id }, { $set: updData });
		}                                                                    //
                                                                       //
		return Collections.Servers.insert(updData);                          // 75
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Refreshes the projects from the server.                            //
  */                                                                   //
	refreshProjects: function () {                                        // 81
		this.service.getProjects(Controllers.Projects.onAddProject);         // 82
	},                                                                    //
                                                                       //
	toggleBuildDisplay: function (buildId, watcher, isDisplayed) {        // 85
		var build = Controllers.Builds.getBuild(buildId);                    // 86
		if (isDisplayed) {                                                   // 87
			build.addWatcher(this._service, watcher);                           // 88
		} else {                                                             //
			build.removeWatcher(watcher);                                       // 90
		}                                                                    //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Refreshes the build history data for all the active builds.        //
  */                                                                   //
	refreshActiveBuildData: function () {                                 // 97
		var self = this;                                                     // 98
		var builds = Controllers.Builds.getActiveServerBuilds(this._id);     // 99
		builds.forEach(function (build) {                                    // 100
			build.refreshBuildData(self._service);                              // 101
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Refreshes the build history data for a single build.               //
  *                                                                    //
  * @param buildId                                                     //
  */                                                                   //
	refreshBuildData: function (buildId) {                                // 110
		var build = Controllers.Builds.getBuild(buildId);                    // 111
		build.refreshBuildData(this._service);                               // 112
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Queries the server for any running builds.                         //
  *                                                                    //
  * @param {Function} cbTimerUpdate                                    //
  */                                                                   //
	queryRunningBuilds: function (cbTimerUpdate) {                        // 120
		var self = this;                                                     // 121
		this._service.queryRunningBuilds(function (builds) {                 // 122
			if (builds.length === 0) {                                          // 123
				self.updateRunningBuilds();                                        // 124
				return cbTimerUpdate(self._id, false);                             // 125
			}                                                                   //
                                                                       //
			builds.forEach(function (build) {                                   // 128
				var bm = Controllers.Builds.getBuildByServiceId(self._id, build.serviceBuildId);
				if (!bm.isBuilding) {                                              // 130
					bm.startBuild(self._service, build.href);                         // 131
				}                                                                  //
			});                                                                 //
                                                                       //
			cbTimerUpdate(self._id, true);                                      // 135
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Updates the running builds from the server.                        //
  */                                                                   //
	updateRunningBuilds: function (cbTimerUpdate) {                       // 142
		var self = this,                                                     // 143
		    builds = Controllers.Builds.getRunningServerBuilds(self._id),    //
		    hasRunningBuilds = false;                                        //
                                                                       //
		builds.forEach(function (build) {                                    // 147
			hasRunningBuilds = true;                                            // 148
			build.updateRunningBuild(self._service);                            // 149
		});                                                                  //
                                                                       //
		if (!hasRunningBuilds && cbTimerUpdate !== undefined) {              // 152
			cbTimerUpdate(self._id, false);                                     // 153
		}                                                                    //
	}                                                                     //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
