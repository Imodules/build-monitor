(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/project.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/11/15.                                         //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
/**                                                                    //
 * @param {{_id: string, serverId: string, serviceProjectId: string,   //
 * serviceParentProjectId: string, name: string, href: string}} doc    //
 * @constructor                                                        //
 */                                                                    //
Models.Project = function (doc) {                                      // 11
	this._doc = doc;                                                      // 12
};                                                                     //
                                                                       //
Models.Project.prototype = {                                           // 15
	//region Properties                                                   //
	get _id() {                                                           // 17
		return this._doc._id;                                                // 18
	},                                                                    //
                                                                       //
	get serverId() {                                                      // 21
		return this._doc.serverId;                                           // 22
	},                                                                    //
                                                                       //
	get parentId() {                                                      // 25
		return this._doc.parentId;                                           // 26
	},                                                                    //
                                                                       //
	get serviceProjectId() {                                              // 29
		return this._doc.serviceProjectId;                                   // 30
	},                                                                    //
                                                                       //
	get serviceParentProjectId() {                                        // 33
		return this._doc.serviceParentProjectId;                             // 34
	},                                                                    //
                                                                       //
	get name() {                                                          // 37
		return this._doc.name;                                               // 38
	},                                                                    //
                                                                       //
	get href() {                                                          // 41
		return this._doc.href;                                               // 42
	},                                                                    //
                                                                       //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	toJson: function () {                                                 // 48
		return this._doc;                                                    // 49
	}                                                                     //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=project.js.map
