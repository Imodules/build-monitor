(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/buildDetail.js                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/7/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
                                                                       //
/**                                                                    //
 * A single change for this build.                                     //
 *                                                                     //
 * @param {{                                                           //
 * id: number|string,                                                  //
 * serviceBuildId: string,                                             //
 * serviceNumber: string,                                              //
 * isSuccess: boolean,                                                 //
 * isBuilding: boolean,                                                //
 * href: string,                                                       //
 * percentageComplete: Number,                                         //
 * statusText: string,                                                 //
 * startDate: Date,                                                    //
 * finishDate: Date,                                                   //
 * usernames: string[]}} doc                                           //
 *                                                                     //
 * @constructor                                                        //
 */                                                                    //
Models.BuildDetail = function (doc) {                                  // 25
	this.json = {                                                         // 26
		id: doc.id,                                                          // 27
		serviceBuildId: doc.serviceBuildId,                                  // 28
		serviceNumber: doc.serviceNumber,                                    // 29
		isSuccess: doc.isSuccess,                                            // 30
		isBuilding: doc.isBuilding,                                          // 31
		href: doc.href,                                                      // 32
		percentageComplete: doc.percentageComplete,                          // 33
		statusText: doc.statusText,                                          // 34
		startDate: doc.startDate,                                            // 35
		finishDate: doc.finishDate,                                          // 36
		usernames: _.map(doc.usernames, function (user) {                    // 37
			var u = new Models.Username(user);                                  // 38
			return u.clean;                                                     // 39
		})                                                                   //
	};                                                                    //
};                                                                     //
                                                                       //
Models.BuildDetail.prototype = {                                       // 44
	//region Properties                                                   //
	get id() {                                                            // 46
		return this.json.id;                                                 // 47
	},                                                                    //
                                                                       //
	get serviceBuildId() {                                                // 50
		return this.json.serviceBuildId;                                     // 51
	},                                                                    //
                                                                       //
	get serviceNumber() {                                                 // 54
		return this.json.serviceNumber;                                      // 55
	},                                                                    //
                                                                       //
	get isSuccess() {                                                     // 58
		return this.json.isSuccess;                                          // 59
	},                                                                    //
                                                                       //
	get isBuilding() {                                                    // 62
		return this.json.isBuilding;                                         // 63
	},                                                                    //
                                                                       //
	get href() {                                                          // 66
		return this.json.href;                                               // 67
	},                                                                    //
                                                                       //
	get percentageComplete() {                                            // 70
		return this.json.percentageComplete;                                 // 71
	},                                                                    //
                                                                       //
	get statusText() {                                                    // 74
		return this.json.statusText;                                         // 75
	},                                                                    //
                                                                       //
	get startDate() {                                                     // 78
		return this.json.startDate;                                          // 79
	},                                                                    //
                                                                       //
	get finishDate() {                                                    // 82
		return this.json.finishDate;                                         // 83
	},                                                                    //
                                                                       //
	get changes() {                                                       // 86
		return this.json.changes;                                            // 87
	},                                                                    //
                                                                       //
	get usernames() {                                                     // 90
		return this.json.usernames;                                          // 91
	},                                                                    //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	toJson: function () {                                                 // 96
		return this.json;                                                    // 97
	}                                                                     //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=buildDetail.js.map
