(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/build.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/7/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
Models.Build = function (doc) {                                        // 6
	this._doc = doc;                                                      // 7
	if (!this._doc.displayCounter) {                                      // 8
		this._doc.displayCounter = 0;                                        // 9
	}                                                                     //
	if (this._doc.isLastBuildSuccess === undefined) {                     // 11
		this._doc.isLastBuildSuccess = true;                                 // 12
	}                                                                     //
	if (this._doc.watchers === undefined) {                               // 14
		this._doc.watchers = [];                                             // 15
	}                                                                     //
};                                                                     //
                                                                       //
Models.Build.prototype = {                                             // 19
	//region Properties                                                   //
	get _id() {                                                           // 21
		return this._doc._id;                                                // 22
	},                                                                    //
                                                                       //
	get serverId() {                                                      // 25
		return this._doc.serverId;                                           // 26
	},                                                                    //
                                                                       //
	get projectId() {                                                     // 29
		return this._doc.projectId;                                          // 30
	},                                                                    //
	set projectId(value) {                                                // 32
		this._doc.projectId = value;                                         // 33
	},                                                                    //
                                                                       //
	get serviceBuildId() {                                                // 36
		return this._doc.serviceBuildId;                                     // 37
	},                                                                    //
                                                                       //
	get name() {                                                          // 40
		return this._doc.name;                                               // 41
	},                                                                    //
                                                                       //
	get href() {                                                          // 44
		return this._doc.href;                                               // 45
	},                                                                    //
                                                                       //
	get watchers() {                                                      // 48
		return this._doc.watchers;                                           // 49
	},                                                                    //
                                                                       //
	/**                                                                   //
  * @returns {boolean}                                                 //
  */                                                                   //
	get isDisplayed() {                                                   // 55
		return this.watchers.length > 0;                                     // 56
	},                                                                    //
                                                                       //
	/**                                                                   //
  * @returns {boolean}                                                 //
  */                                                                   //
	get isLastBuildSuccess() {                                            // 62
		return this._doc.isLastBuildSuccess;                                 // 63
	},                                                                    //
                                                                       //
	/**                                                                   //
  * @returns {boolean}                                                 //
  */                                                                   //
	get isBuilding() {                                                    // 69
		return this._doc.isBuilding;                                         // 70
	},                                                                    //
                                                                       //
	get builds() {                                                        // 73
		return this._doc.builds;                                             // 74
	},                                                                    //
	set builds(value) {                                                   // 76
		this._doc.builds = value;                                            // 77
	},                                                                    //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	toJson: function () {                                                 // 82
		return this._doc;                                                    // 83
	},                                                                    //
                                                                       //
	/**                                                                   //
  *                                                                    //
  * @param {Models.BuildDetail} buildDetail                            //
  * @private                                                           //
  */                                                                   //
	_updateBuild: function (buildDetail) {                                // 91
		// Ensure that our build was started.                                //
		if (this.builds.length > 0 && this.builds[0].id !== buildDetail.id) {
			return;                                                             // 94
		}                                                                    //
                                                                       //
		var set = {                                                          // 97
			'builds.0.isBuilding': buildDetail.isBuilding,                      // 98
			'builds.0.isSuccess': buildDetail.isSuccess,                        // 99
			'builds.0.statusText': buildDetail.statusText,                      // 100
			'builds.0.percentageComplete': buildDetail.percentageComplete       // 101
		};                                                                   //
                                                                       //
		if (this.isLastBuildSuccess && !buildDetail.isSuccess) {             // 104
			set.isLastBuildSuccess = false;                                     // 105
			set.whoBrokeIt = buildDetail.usernames;                             // 106
		}                                                                    //
                                                                       //
		Collections.Builds.update({ _id: this._id }, { $set: set });         // 109
	},                                                                    //
                                                                       //
	/**                                                                   //
  *                                                                    //
  * @param {Models.BuildDetail} buildDetail                            //
  * @private                                                           //
  */                                                                   //
	_finishBuild: function (buildDetail) {                                // 117
		Collections.Builds.update({ _id: this._id }, {                       // 118
			$set: {                                                             // 119
				isLastBuildSuccess: buildDetail.isSuccess,                         // 120
				isBuilding: false,                                                 // 121
				'builds.0.isBuilding': buildDetail.isBuilding,                     // 122
				'builds.0.isSuccess': buildDetail.isSuccess,                       // 123
				'builds.0.statusText': buildDetail.statusText,                     // 124
				'builds.0.percentageComplete': buildDetail.percentageComplete,     // 125
				'builds.0.finishDate': buildDetail.finishDate                      // 126
			}                                                                   //
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Refreshes the build history data for this build.                   //
  *                                                                    //
  * @param service                                                     //
  */                                                                   //
	refreshBuildData: function (service) {                                // 136
		var self = this;                                                     // 137
		service.getBuildData(self.href, 10, function (buildDetailsArray) {   // 138
			var isLastBuildSuccess = true,                                      // 139
			    whoBrokeIt = null;                                              //
			if (buildDetailsArray.length > 0) {                                 // 141
				if (!buildDetailsArray[0].isSuccess) {                             // 142
					isLastBuildSuccess = false;                                       // 143
					whoBrokeIt = buildDetailsArray[0].usernames;                      // 144
				} else if (buildDetailsArray[0].isBuilding && buildDetailsArray.length > 1) {
					isLastBuildSuccess = buildDetailsArray[1].isSuccess;              // 146
					whoBrokeIt = buildDetailsArray[1].usernames;                      // 147
				}                                                                  //
			}                                                                   //
                                                                       //
			var buildData = _.map(buildDetailsArray, function (bd) {            // 151
				return bd.toJson();                                                // 152
			});                                                                 //
                                                                       //
			Collections.Builds.update({ _id: self._id }, {                      // 155
				$set: {                                                            // 156
					isLastBuildSuccess: isLastBuildSuccess,                           // 157
					whoBrokeIt: whoBrokeIt,                                           // 158
					builds: buildData                                                 // 159
				}                                                                  //
			});                                                                 //
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Starts a new build for this buildType.                             //
  *                                                                    //
  * @param service                                                     //
  * @param href                                                        //
  */                                                                   //
	startBuild: function (service, href) {                                // 171
		var self = this;                                                     // 172
		service.getBuildDetails(href, function (buildDetail) {               // 173
			if (!self.builds) {                                                 // 174
				self.builds = [];                                                  // 175
			}                                                                   //
                                                                       //
			self.builds.splice(0, 0, buildDetail.toJson());                     // 178
			while (self.builds.length > 10) {                                   // 179
				self.builds.pop();                                                 // 180
			}                                                                   //
                                                                       //
			Collections.Builds.update({ _id: self._id }, { $set: { isBuilding: true, builds: self.builds } });
		});                                                                  //
	},                                                                    //
                                                                       //
	/**                                                                   //
  * Updates the latest build information.                              //
  *                                                                    //
  * @param service                                                     //
  */                                                                   //
	updateRunningBuild: function (service) {                              // 192
		var self = this,                                                     // 193
		    build = self.builds[0];                                          //
		service.getBuildDetails(build.href, function (buildDetail) {         // 195
			self._updateBuild(buildDetail);                                     // 196
			if (!buildDetail.isBuilding) {                                      // 197
				self._finishBuild(buildDetail);                                    // 198
			}                                                                   //
		});                                                                  //
	},                                                                    //
                                                                       //
	addWatcher: function (service, watcher) {                             // 203
		if (_.contains(this.watchers, watcher)) {                            // 204
			return;                                                             // 205
		}                                                                    //
                                                                       //
		this._doc.watchers.push(watcher);                                    // 208
		Collections.Builds.update({ _id: this._id }, {                       // 209
			$addToSet: { watchers: watcher },                                   // 210
			$set: { watcherCount: this.watchers.length }                        // 211
		});                                                                  //
                                                                       //
		if (this.watchers.length === 1 && service) {                         // 214
			this.refreshBuildData(service);                                     // 215
		}                                                                    //
	},                                                                    //
                                                                       //
	removeWatcher: function (watcher) {                                   // 219
		var nWatchers = _.reject(this.watchers, function (w) {               // 220
			return w === watcher;                                               // 221
		});                                                                  //
                                                                       //
		if (nWatchers.length === this.watchers.length) {                     // 224
			return;                                                             // 225
		}                                                                    //
                                                                       //
		this._doc.watchers = nWatchers;                                      // 228
		Collections.Builds.update({ _id: this._id }, { $set: { watchers: nWatchers, watcherCount: this.watchers.length } });
	}                                                                     //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=build.js.map
