(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/username.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/7/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
function cleanUsername(username) {                                     // 6
	var clean = username,                                                 // 7
	    idx = username.indexOf('\\');                                     //
                                                                       //
	if (idx > -1) {                                                       // 10
		clean = clean.substr(idx + 1);                                       // 11
	}                                                                     //
                                                                       //
	idx = clean.indexOf('<');                                             // 14
	if (idx > -1) {                                                       // 15
		clean = clean.substr(0, idx);                                        // 16
	}                                                                     //
                                                                       //
	return clean.trim();                                                  // 19
}                                                                      //
                                                                       //
Models.Username = function (username) {                                // 22
	this._raw = username;                                                 // 23
	this._clean = cleanUsername(username);                                // 24
};                                                                     //
                                                                       //
Models.Username.prototype = {                                          // 27
	//region Properties                                                   //
	get raw() {                                                           // 29
		return this._raw;                                                    // 30
	},                                                                    //
	get clean() {                                                         // 32
		return this._clean;                                                  // 33
	}                                                                     //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=username.js.map
