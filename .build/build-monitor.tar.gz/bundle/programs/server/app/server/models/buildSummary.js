(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/models/buildSummary.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by paul on 5/9/15.                                          //
 */                                                                    //
                                                                       //
'use strict';                                                          // 5
/**                                                                    //
 * A single change for this build.                                     //
 *                                                                     //
 * @param {{                                                           //
 * id: number|string,                                                  //
 * serviceBuildId: string,                                             //
 * serviceNumber: string,                                              //
 * isSuccess: boolean,                                                 //
 * isBuilding: boolean,                                                //
 * href: string}} doc                                                  //
 *                                                                     //
 * @constructor                                                        //
 */                                                                    //
Models.BuildSummary = function (doc) {                                 // 19
	this.json = {                                                         // 20
		id: doc.id,                                                          // 21
		serviceBuildId: doc.serviceBuildId,                                  // 22
		serviceNumber: doc.serviceNumber,                                    // 23
		isSuccess: doc.isSuccess,                                            // 24
		isBuilding: doc.isBuilding,                                          // 25
		href: doc.href                                                       // 26
	};                                                                    //
};                                                                     //
                                                                       //
Models.BuildSummary.prototype = {                                      // 30
	//region Properties                                                   //
	get id() {                                                            // 32
		return this.json.id;                                                 // 33
	},                                                                    //
                                                                       //
	get serviceBuildId() {                                                // 36
		return this.json.serviceBuildId;                                     // 37
	},                                                                    //
                                                                       //
	get serviceNumber() {                                                 // 40
		return this.json.serviceNumber;                                      // 41
	},                                                                    //
                                                                       //
	get isSuccess() {                                                     // 44
		return this.json.isSuccess;                                          // 45
	},                                                                    //
                                                                       //
	get isBuilding() {                                                    // 48
		return this.json.isBuilding;                                         // 49
	},                                                                    //
                                                                       //
	get href() {                                                          // 52
		return this.json.href;                                               // 53
	},                                                                    //
	//endregion                                                           //
                                                                       //
	//region Methods                                                      //
	toJson: function () {                                                 // 58
		return this.json;                                                    // 59
	}                                                                     //
	//endregion                                                           //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=buildSummary.js.map
