var require = meteorInstall({"lib":{"ext":{"bower_components":{"underscore.string":{"underscore.string.js":["babel-runtime/helpers/typeof","./trim","./decapitalize","./helper/makeString","./capitalize","./camelize","./helper/toPositive","./helper/escapeChars","./makeString","./escapeRegExp","./underscored","./isBlank","./stripTags","./chop","./clean","./cleanDiacritics","./count","./chars","./swapCase","./escapeHTML","./unescapeHTML","./splice","./insert","./replaceAll","./include","./join","./lines","./dedent","./reverse","./startsWith","./endsWith","./pred","./succ","./titleize","./dasherize","./classify","./humanize","./ltrim","./rtrim","./truncate","./prune","./words","./pad","./lpad","./rpad","./lrpad","./sprintf","./vsprintf","./toNumber","./numberFormat","./strRight","./strRightBack","./strLeft","./strLeftBack","./toSentence","./toSentenceSerial","./slugify","./surround","./quote","./unquote","./repeat","./naturalCmp","./levenshtein","./toBoolean","./exports","./helper/escapeRegExp","./wrap","./map","./helper/defaultToWhiteSpace","./helper/strRepeat","./helper/adjacent","util-deprecate","sprintf-js","./helper/htmlEntities",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/ext/bower_components/underscore.string/underscore.string.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                               //
                                                                                                                      //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    //
* Underscore.string                                                                                                   //
* (c) 2010 Esa-Matti Suuronen <esa-matti aet suuronen dot org>                                                        //
* Underscore.string is freely distributable under the terms of the MIT license.                                       //
* Documentation: https://github.com/epeli/underscore.string                                                           //
* Some code is borrowed from MooTools and Alexandru Marasteanu.                                                       //
* Version '3.3.4'                                                                                                     //
* @preserve                                                                                                           //
*/                                                                                                                    //
                                                                                                                      //
(function (f) {                                                                                                       // 11
  if ((typeof exports === "undefined" ? "undefined" : (0, _typeof3["default"])(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();                                                                                             // 11
  } else if (typeof define === "function" && define.amd) {                                                            //
    define([], f);                                                                                                    // 11
  } else {                                                                                                            //
    var g;if (typeof window !== "undefined") {                                                                        // 11
      g = window;                                                                                                     // 11
    } else if (typeof global !== "undefined") {                                                                       //
      g = global;                                                                                                     // 11
    } else if (typeof self !== "undefined") {                                                                         //
      g = self;                                                                                                       // 11
    } else {                                                                                                          //
      g = this;                                                                                                       // 11
    }g.s = f();                                                                                                       //
  }                                                                                                                   //
})(function () {                                                                                                      //
  var define, module, exports;return function () {                                                                    // 11
    function e(t, n, r) {                                                                                             // 11
      function s(o, u) {                                                                                              // 11
        if (!n[o]) {                                                                                                  // 11
          if (!t[o]) {                                                                                                // 11
            var a = typeof require == "function" && require;if (!u && a) return a(o, !0);if (i) return i(o, !0);var f = new Error("Cannot find module '" + o + "'");throw f.code = "MODULE_NOT_FOUND", f;
          }var l = n[o] = { exports: {} };t[o][0].call(l.exports, function (e) {                                      //
            var n = t[o][1][e];return s(n ? n : e);                                                                   // 11
          }, l, l.exports, e, t, n, r);                                                                               //
        }return n[o].exports;                                                                                         //
      }var i = typeof require == "function" && require;for (var o = 0; o < r.length; o++) {                           //
        s(r[o]);                                                                                                      // 11
      }return s;                                                                                                      //
    }                                                                                                                 //
                                                                                                                      //
    return e;                                                                                                         //
  }()({ 1: [function (require, module, exports) {                                                                     //
      var trim = require('./trim');                                                                                   // 12
      var decap = require('./decapitalize');                                                                          // 13
                                                                                                                      //
      module.exports = function () {                                                                                  // 15
        function camelize(str, decapitalize) {                                                                        // 15
          str = trim(str).replace(/[-_\s]+(.)?/g, function (match, c) {                                               // 16
            return c ? c.toUpperCase() : '';                                                                          // 17
          });                                                                                                         //
                                                                                                                      //
          if (decapitalize === true) {                                                                                // 20
            return decap(str);                                                                                        // 21
          } else {                                                                                                    //
            return str;                                                                                               // 23
          }                                                                                                           //
        }                                                                                                             //
                                                                                                                      //
        return camelize;                                                                                              //
      }();                                                                                                            //
    }, { "./decapitalize": 10, "./trim": 65 }], 2: [function (require, module, exports) {                             //
      var makeString = require('./helper/makeString');                                                                // 28
                                                                                                                      //
      module.exports = function () {                                                                                  // 30
        function capitalize(str, lowercaseRest) {                                                                     // 30
          str = makeString(str);                                                                                      // 31
          var remainingChars = !lowercaseRest ? str.slice(1) : str.slice(1).toLowerCase();                            // 32
                                                                                                                      //
          return str.charAt(0).toUpperCase() + remainingChars;                                                        // 34
        }                                                                                                             //
                                                                                                                      //
        return capitalize;                                                                                            //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 3: [function (require, module, exports) {                                      //
      var makeString = require('./helper/makeString');                                                                // 38
                                                                                                                      //
      module.exports = function () {                                                                                  // 40
        function chars(str) {                                                                                         // 40
          return makeString(str).split('');                                                                           // 41
        }                                                                                                             //
                                                                                                                      //
        return chars;                                                                                                 //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 4: [function (require, module, exports) {                                      //
      module.exports = function () {                                                                                  // 45
        function chop(str, step) {                                                                                    // 45
          if (str == null) return [];                                                                                 // 46
          str = String(str);                                                                                          // 47
          step = ~ ~step;                                                                                             // 48
          return step > 0 ? str.match(new RegExp('.{1,' + step + '}', 'g')) : [str];                                  // 49
        }                                                                                                             //
                                                                                                                      //
        return chop;                                                                                                  //
      }();                                                                                                            //
    }, {}], 5: [function (require, module, exports) {                                                                 //
      var capitalize = require('./capitalize');                                                                       // 53
      var camelize = require('./camelize');                                                                           // 54
      var makeString = require('./helper/makeString');                                                                // 55
                                                                                                                      //
      module.exports = function () {                                                                                  // 57
        function classify(str) {                                                                                      // 57
          str = makeString(str);                                                                                      // 58
          return capitalize(camelize(str.replace(/[\W_]/g, ' ')).replace(/\s/g, ''));                                 // 59
        }                                                                                                             //
                                                                                                                      //
        return classify;                                                                                              //
      }();                                                                                                            //
    }, { "./camelize": 1, "./capitalize": 2, "./helper/makeString": 20 }], 6: [function (require, module, exports) {  //
      var trim = require('./trim');                                                                                   // 63
                                                                                                                      //
      module.exports = function () {                                                                                  // 65
        function clean(str) {                                                                                         // 65
          return trim(str).replace(/\s\s+/g, ' ');                                                                    // 66
        }                                                                                                             //
                                                                                                                      //
        return clean;                                                                                                 //
      }();                                                                                                            //
    }, { "./trim": 65 }], 7: [function (require, module, exports) {                                                   //
                                                                                                                      //
      var makeString = require('./helper/makeString');                                                                // 71
                                                                                                                      //
      var from = 'ąàáäâãåæăćčĉęèéëêĝĥìíïîĵłľńňòóöőôõðøśșşšŝťțţŭùúüűûñÿýçżźž',                                         // 73
          to = 'aaaaaaaaaccceeeeeghiiiijllnnoooooooossssstttuuuuuunyyczzz';                                           //
                                                                                                                      //
      from += from.toUpperCase();                                                                                     // 76
      to += to.toUpperCase();                                                                                         // 77
                                                                                                                      //
      to = to.split('');                                                                                              // 79
                                                                                                                      //
      // for tokens requireing multitoken output                                                                      //
      from += 'ß';                                                                                                    // 69
      to.push('ss');                                                                                                  // 83
                                                                                                                      //
      module.exports = function () {                                                                                  // 86
        function cleanDiacritics(str) {                                                                               // 86
          return makeString(str).replace(/.{1}/g, function (c) {                                                      // 87
            var index = from.indexOf(c);                                                                              // 88
            return index === -1 ? c : to[index];                                                                      // 89
          });                                                                                                         //
        }                                                                                                             //
                                                                                                                      //
        return cleanDiacritics;                                                                                       //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 8: [function (require, module, exports) {                                      //
      var makeString = require('./helper/makeString');                                                                // 94
                                                                                                                      //
      module.exports = function (str, substr) {                                                                       // 96
        str = makeString(str);                                                                                        // 97
        substr = makeString(substr);                                                                                  // 98
                                                                                                                      //
        if (str.length === 0 || substr.length === 0) return 0;                                                        // 100
                                                                                                                      //
        return str.split(substr).length - 1;                                                                          // 102
      };                                                                                                              //
    }, { "./helper/makeString": 20 }], 9: [function (require, module, exports) {                                      //
      var trim = require('./trim');                                                                                   // 106
                                                                                                                      //
      module.exports = function () {                                                                                  // 108
        function dasherize(str) {                                                                                     // 108
          return trim(str).replace(/([A-Z])/g, '-$1').replace(/[-_\s]+/g, '-').toLowerCase();                         // 109
        }                                                                                                             //
                                                                                                                      //
        return dasherize;                                                                                             //
      }();                                                                                                            //
    }, { "./trim": 65 }], 10: [function (require, module, exports) {                                                  //
      var makeString = require('./helper/makeString');                                                                // 113
                                                                                                                      //
      module.exports = function () {                                                                                  // 115
        function decapitalize(str) {                                                                                  // 115
          str = makeString(str);                                                                                      // 116
          return str.charAt(0).toLowerCase() + str.slice(1);                                                          // 117
        }                                                                                                             //
                                                                                                                      //
        return decapitalize;                                                                                          //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 11: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 121
                                                                                                                      //
      function getIndent(str) {                                                                                       // 123
        var matches = str.match(/^[\s\\t]*/gm);                                                                       // 124
        var indent = matches[0].length;                                                                               // 125
                                                                                                                      //
        for (var i = 1; i < matches.length; i++) {                                                                    // 127
          indent = Math.min(matches[i].length, indent);                                                               // 128
        }                                                                                                             //
                                                                                                                      //
        return indent;                                                                                                // 131
      }                                                                                                               //
                                                                                                                      //
      module.exports = function () {                                                                                  // 134
        function dedent(str, pattern) {                                                                               // 134
          str = makeString(str);                                                                                      // 135
          var indent = getIndent(str);                                                                                // 136
          var reg;                                                                                                    // 137
                                                                                                                      //
          if (indent === 0) return str;                                                                               // 139
                                                                                                                      //
          if (typeof pattern === 'string') {                                                                          // 141
            reg = new RegExp('^' + pattern, 'gm');                                                                    // 142
          } else {                                                                                                    //
            reg = new RegExp('^[ \\t]{' + indent + '}', 'gm');                                                        // 144
          }                                                                                                           //
                                                                                                                      //
          return str.replace(reg, '');                                                                                // 147
        }                                                                                                             //
                                                                                                                      //
        return dedent;                                                                                                //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 12: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 151
      var toPositive = require('./helper/toPositive');                                                                // 152
                                                                                                                      //
      module.exports = function () {                                                                                  // 154
        function endsWith(str, ends, position) {                                                                      // 154
          str = makeString(str);                                                                                      // 155
          ends = '' + ends;                                                                                           // 156
          if (typeof position == 'undefined') {                                                                       // 157
            position = str.length - ends.length;                                                                      // 158
          } else {                                                                                                    //
            position = Math.min(toPositive(position), str.length) - ends.length;                                      // 160
          }                                                                                                           //
          return position >= 0 && str.indexOf(ends, position) === position;                                           // 162
        }                                                                                                             //
                                                                                                                      //
        return endsWith;                                                                                              //
      }();                                                                                                            //
    }, { "./helper/makeString": 20, "./helper/toPositive": 22 }], 13: [function (require, module, exports) {          //
      var makeString = require('./helper/makeString');                                                                // 166
      var escapeChars = require('./helper/escapeChars');                                                              // 167
                                                                                                                      //
      var regexString = '[';                                                                                          // 169
      for (var key in meteorBabelHelpers.sanitizeForInObject(escapeChars)) {                                          // 170
        regexString += key;                                                                                           // 171
      }                                                                                                               //
      regexString += ']';                                                                                             // 173
                                                                                                                      //
      var regex = new RegExp(regexString, 'g');                                                                       // 175
                                                                                                                      //
      module.exports = function () {                                                                                  // 177
        function escapeHTML(str) {                                                                                    // 177
                                                                                                                      //
          return makeString(str).replace(regex, function (m) {                                                        // 179
            return '&' + escapeChars[m] + ';';                                                                        // 180
          });                                                                                                         //
        }                                                                                                             //
                                                                                                                      //
        return escapeHTML;                                                                                            //
      }();                                                                                                            //
    }, { "./helper/escapeChars": 17, "./helper/makeString": 20 }], 14: [function (require, module, exports) {         //
      module.exports = function () {                                                                                  // 185
        var result = {};                                                                                              // 186
                                                                                                                      //
        for (var prop in meteorBabelHelpers.sanitizeForInObject(this)) {                                              // 188
          if (!this.hasOwnProperty(prop) || prop.match(/^(?:include|contains|reverse|join|map|wrap)$/)) continue;     // 189
          result[prop] = this[prop];                                                                                  // 190
        }                                                                                                             //
                                                                                                                      //
        return result;                                                                                                // 193
      };                                                                                                              //
    }, {}], 15: [function (require, module, exports) {                                                                //
      var makeString = require('./makeString');                                                                       // 197
                                                                                                                      //
      module.exports = function () {                                                                                  // 199
        function adjacent(str, direction) {                                                                           // 199
          str = makeString(str);                                                                                      // 200
          if (str.length === 0) {                                                                                     // 201
            return '';                                                                                                // 202
          }                                                                                                           //
          return str.slice(0, -1) + String.fromCharCode(str.charCodeAt(str.length - 1) + direction);                  // 204
        }                                                                                                             //
                                                                                                                      //
        return adjacent;                                                                                              //
      }();                                                                                                            //
    }, { "./makeString": 20 }], 16: [function (require, module, exports) {                                            //
      var escapeRegExp = require('./escapeRegExp');                                                                   // 208
                                                                                                                      //
      module.exports = function () {                                                                                  // 210
        function defaultToWhiteSpace(characters) {                                                                    // 210
          if (characters == null) return '\\s';else if (characters.source) return characters.source;else return '[' + escapeRegExp(characters) + ']';
        }                                                                                                             //
                                                                                                                      //
        return defaultToWhiteSpace;                                                                                   //
      }();                                                                                                            //
    }, { "./escapeRegExp": 18 }], 17: [function (require, module, exports) {                                          //
      /* We're explicitly defining the list of entities we want to escape.                                            //
      nbsp is an HTML entity, but we don't want to escape all space characters in a string, hence its omission in this map.
                                                                                                                      //
      */                                                                                                              //
      var escapeChars = {                                                                                             // 224
        '¢': 'cent',                                                                                                  // 225
        '£': 'pound',                                                                                                 // 226
        '¥': 'yen',                                                                                                   // 227
        '€': 'euro',                                                                                                  // 228
        '©': 'copy',                                                                                                  // 229
        '®': 'reg',                                                                                                   // 230
        '<': 'lt',                                                                                                    // 231
        '>': 'gt',                                                                                                    // 232
        '"': 'quot',                                                                                                  // 233
        '&': 'amp',                                                                                                   // 234
        '\'': '#39'                                                                                                   // 235
      };                                                                                                              //
                                                                                                                      //
      module.exports = escapeChars;                                                                                   // 238
    }, {}], 18: [function (require, module, exports) {                                                                //
      var makeString = require('./makeString');                                                                       // 241
                                                                                                                      //
      module.exports = function () {                                                                                  // 243
        function escapeRegExp(str) {                                                                                  // 243
          return makeString(str).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');                                       // 244
        }                                                                                                             //
                                                                                                                      //
        return escapeRegExp;                                                                                          //
      }();                                                                                                            //
    }, { "./makeString": 20 }], 19: [function (require, module, exports) {                                            //
      /*                                                                                                              //
      We're explicitly defining the list of entities that might see in escape HTML strings                            //
      */                                                                                                              //
      var htmlEntities = {                                                                                            // 251
        nbsp: ' ',                                                                                                    // 252
        cent: '¢',                                                                                                    // 253
        pound: '£',                                                                                                   // 254
        yen: '¥',                                                                                                     // 255
        euro: '€',                                                                                                    // 256
        copy: '©',                                                                                                    // 257
        reg: '®',                                                                                                     // 258
        lt: '<',                                                                                                      // 259
        gt: '>',                                                                                                      // 260
        quot: '"',                                                                                                    // 261
        amp: '&',                                                                                                     // 262
        apos: '\''                                                                                                    // 263
      };                                                                                                              //
                                                                                                                      //
      module.exports = htmlEntities;                                                                                  // 266
    }, {}], 20: [function (require, module, exports) {                                                                //
      /**                                                                                                             //
       * Ensure some object is a coerced to a string                                                                  //
       **/                                                                                                            //
      module.exports = function () {                                                                                  // 272
        function makeString(object) {                                                                                 // 272
          if (object == null) return '';                                                                              // 273
          return '' + object;                                                                                         // 274
        }                                                                                                             //
                                                                                                                      //
        return makeString;                                                                                            //
      }();                                                                                                            //
    }, {}], 21: [function (require, module, exports) {                                                                //
      module.exports = function () {                                                                                  // 278
        function strRepeat(str, qty) {                                                                                // 278
          if (qty < 1) return '';                                                                                     // 279
          var result = '';                                                                                            // 280
          while (qty > 0) {                                                                                           // 281
            if (qty & 1) result += str;                                                                               // 282
            qty >>= 1, str += str;                                                                                    // 283
          }                                                                                                           //
          return result;                                                                                              // 285
        }                                                                                                             //
                                                                                                                      //
        return strRepeat;                                                                                             //
      }();                                                                                                            //
    }, {}], 22: [function (require, module, exports) {                                                                //
      module.exports = function () {                                                                                  // 289
        function toPositive(number) {                                                                                 // 289
          return number < 0 ? 0 : +number || 0;                                                                       // 290
        }                                                                                                             //
                                                                                                                      //
        return toPositive;                                                                                            //
      }();                                                                                                            //
    }, {}], 23: [function (require, module, exports) {                                                                //
      var capitalize = require('./capitalize');                                                                       // 294
      var underscored = require('./underscored');                                                                     // 295
      var trim = require('./trim');                                                                                   // 296
                                                                                                                      //
      module.exports = function () {                                                                                  // 298
        function humanize(str) {                                                                                      // 298
          return capitalize(trim(underscored(str).replace(/_id$/, '').replace(/_/g, ' ')));                           // 299
        }                                                                                                             //
                                                                                                                      //
        return humanize;                                                                                              //
      }();                                                                                                            //
    }, { "./capitalize": 2, "./trim": 65, "./underscored": 67 }], 24: [function (require, module, exports) {          //
      var makeString = require('./helper/makeString');                                                                // 303
                                                                                                                      //
      module.exports = function () {                                                                                  // 305
        function include(str, needle) {                                                                               // 305
          if (needle === '') return true;                                                                             // 306
          return makeString(str).indexOf(needle) !== -1;                                                              // 307
        }                                                                                                             //
                                                                                                                      //
        return include;                                                                                               //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 25: [function (require, module, exports) {                                     //
      /*                                                                                                              //
      * Underscore.string                                                                                             //
      * (c) 2010 Esa-Matti Suuronen <esa-matti aet suuronen dot org>                                                  //
      * Underscore.string is freely distributable under the terms of the MIT license.                                 //
      * Documentation: https://github.com/epeli/underscore.string                                                     //
      * Some code is borrowed from MooTools and Alexandru Marasteanu.                                                 //
      * Version '3.3.4'                                                                                               //
      * @preserve                                                                                                     //
      */                                                                                                              //
                                                                                                                      //
      'use strict';                                                                                                   // 321
                                                                                                                      //
      function s(value) {                                                                                             // 323
        /* jshint validthis: true */                                                                                  //
        if (!(this instanceof s)) return new s(value);                                                                // 325
        this._wrapped = value;                                                                                        // 326
      }                                                                                                               //
                                                                                                                      //
      s.VERSION = '3.3.4';                                                                                            // 329
                                                                                                                      //
      s.isBlank = require('./isBlank');                                                                               // 331
      s.stripTags = require('./stripTags');                                                                           // 332
      s.capitalize = require('./capitalize');                                                                         // 333
      s.decapitalize = require('./decapitalize');                                                                     // 334
      s.chop = require('./chop');                                                                                     // 335
      s.trim = require('./trim');                                                                                     // 336
      s.clean = require('./clean');                                                                                   // 337
      s.cleanDiacritics = require('./cleanDiacritics');                                                               // 338
      s.count = require('./count');                                                                                   // 339
      s.chars = require('./chars');                                                                                   // 340
      s.swapCase = require('./swapCase');                                                                             // 341
      s.escapeHTML = require('./escapeHTML');                                                                         // 342
      s.unescapeHTML = require('./unescapeHTML');                                                                     // 343
      s.splice = require('./splice');                                                                                 // 344
      s.insert = require('./insert');                                                                                 // 345
      s.replaceAll = require('./replaceAll');                                                                         // 346
      s.include = require('./include');                                                                               // 347
      s.join = require('./join');                                                                                     // 348
      s.lines = require('./lines');                                                                                   // 349
      s.dedent = require('./dedent');                                                                                 // 350
      s.reverse = require('./reverse');                                                                               // 351
      s.startsWith = require('./startsWith');                                                                         // 352
      s.endsWith = require('./endsWith');                                                                             // 353
      s.pred = require('./pred');                                                                                     // 354
      s.succ = require('./succ');                                                                                     // 355
      s.titleize = require('./titleize');                                                                             // 356
      s.camelize = require('./camelize');                                                                             // 357
      s.underscored = require('./underscored');                                                                       // 358
      s.dasherize = require('./dasherize');                                                                           // 359
      s.classify = require('./classify');                                                                             // 360
      s.humanize = require('./humanize');                                                                             // 361
      s.ltrim = require('./ltrim');                                                                                   // 362
      s.rtrim = require('./rtrim');                                                                                   // 363
      s.truncate = require('./truncate');                                                                             // 364
      s.prune = require('./prune');                                                                                   // 365
      s.words = require('./words');                                                                                   // 366
      s.pad = require('./pad');                                                                                       // 367
      s.lpad = require('./lpad');                                                                                     // 368
      s.rpad = require('./rpad');                                                                                     // 369
      s.lrpad = require('./lrpad');                                                                                   // 370
      s.sprintf = require('./sprintf');                                                                               // 371
      s.vsprintf = require('./vsprintf');                                                                             // 372
      s.toNumber = require('./toNumber');                                                                             // 373
      s.numberFormat = require('./numberFormat');                                                                     // 374
      s.strRight = require('./strRight');                                                                             // 375
      s.strRightBack = require('./strRightBack');                                                                     // 376
      s.strLeft = require('./strLeft');                                                                               // 377
      s.strLeftBack = require('./strLeftBack');                                                                       // 378
      s.toSentence = require('./toSentence');                                                                         // 379
      s.toSentenceSerial = require('./toSentenceSerial');                                                             // 380
      s.slugify = require('./slugify');                                                                               // 381
      s.surround = require('./surround');                                                                             // 382
      s.quote = require('./quote');                                                                                   // 383
      s.unquote = require('./unquote');                                                                               // 384
      s.repeat = require('./repeat');                                                                                 // 385
      s.naturalCmp = require('./naturalCmp');                                                                         // 386
      s.levenshtein = require('./levenshtein');                                                                       // 387
      s.toBoolean = require('./toBoolean');                                                                           // 388
      s.exports = require('./exports');                                                                               // 389
      s.escapeRegExp = require('./helper/escapeRegExp');                                                              // 390
      s.wrap = require('./wrap');                                                                                     // 391
      s.map = require('./map');                                                                                       // 392
                                                                                                                      //
      // Aliases                                                                                                      //
      s.strip = s.trim;                                                                                               // 310
      s.lstrip = s.ltrim;                                                                                             // 396
      s.rstrip = s.rtrim;                                                                                             // 397
      s.center = s.lrpad;                                                                                             // 398
      s.rjust = s.lpad;                                                                                               // 399
      s.ljust = s.rpad;                                                                                               // 400
      s.contains = s.include;                                                                                         // 401
      s.q = s.quote;                                                                                                  // 402
      s.toBool = s.toBoolean;                                                                                         // 403
      s.camelcase = s.camelize;                                                                                       // 404
      s.mapChars = s.map;                                                                                             // 405
                                                                                                                      //
      // Implement chaining                                                                                           //
      s.prototype = {                                                                                                 // 310
        value: function () {                                                                                          // 410
          function value() {                                                                                          // 410
            return this._wrapped;                                                                                     // 411
          }                                                                                                           //
                                                                                                                      //
          return value;                                                                                               //
        }()                                                                                                           //
      };                                                                                                              //
                                                                                                                      //
      function fn2method(key, fn) {                                                                                   // 415
        if (typeof fn !== 'function') return;                                                                         // 416
        s.prototype[key] = function () {                                                                              // 417
          var args = [this._wrapped].concat(Array.prototype.slice.call(arguments));                                   // 418
          var res = fn.apply(null, args);                                                                             // 419
          // if the result is non-string stop the chain and return the value                                          //
          return typeof res === 'string' ? new s(res) : res;                                                          // 417
        };                                                                                                            //
      }                                                                                                               //
                                                                                                                      //
      // Copy functions to instance methods for chaining                                                              //
      for (var key in meteorBabelHelpers.sanitizeForInObject(s)) {                                                    // 310
        fn2method(key, s[key]);                                                                                       // 426
      }fn2method('tap', function () {                                                                                 //
        function tap(string, fn) {                                                                                    // 428
          return fn(string);                                                                                          // 429
        }                                                                                                             //
                                                                                                                      //
        return tap;                                                                                                   //
      }());                                                                                                           //
                                                                                                                      //
      function prototype2method(methodName) {                                                                         // 432
        fn2method(methodName, function (context) {                                                                    // 433
          var args = Array.prototype.slice.call(arguments, 1);                                                        // 434
          return String.prototype[methodName].apply(context, args);                                                   // 435
        });                                                                                                           //
      }                                                                                                               //
                                                                                                                      //
      var prototypeMethods = ['toUpperCase', 'toLowerCase', 'split', 'replace', 'slice', 'substring', 'substr', 'concat'];
                                                                                                                      //
      for (var method in meteorBabelHelpers.sanitizeForInObject(prototypeMethods)) {                                  // 450
        prototype2method(prototypeMethods[method]);                                                                   // 450
      }module.exports = s;                                                                                            //
    }, { "./camelize": 1, "./capitalize": 2, "./chars": 3, "./chop": 4, "./classify": 5, "./clean": 6, "./cleanDiacritics": 7, "./count": 8, "./dasherize": 9, "./decapitalize": 10, "./dedent": 11, "./endsWith": 12, "./escapeHTML": 13, "./exports": 14, "./helper/escapeRegExp": 18, "./humanize": 23, "./include": 24, "./insert": 26, "./isBlank": 27, "./join": 28, "./levenshtein": 29, "./lines": 30, "./lpad": 31, "./lrpad": 32, "./ltrim": 33, "./map": 34, "./naturalCmp": 35, "./numberFormat": 38, "./pad": 39, "./pred": 40, "./prune": 41, "./quote": 42, "./repeat": 43, "./replaceAll": 44, "./reverse": 45, "./rpad": 46, "./rtrim": 47, "./slugify": 48, "./splice": 49, "./sprintf": 50, "./startsWith": 51, "./strLeft": 52, "./strLeftBack": 53, "./strRight": 54, "./strRightBack": 55, "./stripTags": 56, "./succ": 57, "./surround": 58, "./swapCase": 59, "./titleize": 60, "./toBoolean": 61, "./toNumber": 62, "./toSentence": 63, "./toSentenceSerial": 64, "./trim": 65, "./truncate": 66, "./underscored": 67, "./unescapeHTML": 68, "./unquote": 69, "./vsprintf": 70, "./words": 71, "./wrap": 72 }], 26: [function (require, module, exports) {
      var splice = require('./splice');                                                                               // 456
                                                                                                                      //
      module.exports = function () {                                                                                  // 458
        function insert(str, i, substr) {                                                                             // 458
          return splice(str, i, 0, substr);                                                                           // 459
        }                                                                                                             //
                                                                                                                      //
        return insert;                                                                                                //
      }();                                                                                                            //
    }, { "./splice": 49 }], 27: [function (require, module, exports) {                                                //
      var makeString = require('./helper/makeString');                                                                // 463
                                                                                                                      //
      module.exports = function () {                                                                                  // 465
        function isBlank(str) {                                                                                       // 465
          return (/^\s*$/.test(makeString(str))                                                                       // 466
          );                                                                                                          //
        }                                                                                                             //
                                                                                                                      //
        return isBlank;                                                                                               //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 28: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 470
      var slice = [].slice;                                                                                           // 471
                                                                                                                      //
      module.exports = function () {                                                                                  // 473
        function join() {                                                                                             // 473
          var args = slice.call(arguments),                                                                           // 474
              separator = args.shift();                                                                               //
                                                                                                                      //
          return args.join(makeString(separator));                                                                    // 477
        }                                                                                                             //
                                                                                                                      //
        return join;                                                                                                  //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 29: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 481
                                                                                                                      //
      /**                                                                                                             //
       * Based on the implementation here: https://github.com/hiddentao/fast-levenshtein                              //
       */                                                                                                             //
      module.exports = function () {                                                                                  // 480
        function levenshtein(str1, str2) {                                                                            // 486
          'use strict';                                                                                               // 487
                                                                                                                      //
          str1 = makeString(str1);                                                                                    // 488
          str2 = makeString(str2);                                                                                    // 489
                                                                                                                      //
          // Short cut cases                                                                                          //
          if (str1 === str2) return 0;                                                                                // 486
          if (!str1 || !str2) return Math.max(str1.length, str2.length);                                              // 493
                                                                                                                      //
          // two rows                                                                                                 //
          var prevRow = new Array(str2.length + 1);                                                                   // 486
                                                                                                                      //
          // initialise previous row                                                                                  //
          for (var i = 0; i < prevRow.length; ++i) {                                                                  // 486
            prevRow[i] = i;                                                                                           // 500
          }                                                                                                           //
                                                                                                                      //
          // calculate current row distance from previous row                                                         //
          for (i = 0; i < str1.length; ++i) {                                                                         // 486
            var nextCol = i + 1;                                                                                      // 505
                                                                                                                      //
            for (var j = 0; j < str2.length; ++j) {                                                                   // 507
              var curCol = nextCol;                                                                                   // 508
                                                                                                                      //
              // substution                                                                                           //
              nextCol = prevRow[j] + (str1.charAt(i) === str2.charAt(j) ? 0 : 1);                                     // 507
              // insertion                                                                                            //
              var tmp = curCol + 1;                                                                                   // 507
              if (nextCol > tmp) {                                                                                    // 514
                nextCol = tmp;                                                                                        // 515
              }                                                                                                       //
              // deletion                                                                                             //
              tmp = prevRow[j + 1] + 1;                                                                               // 507
              if (nextCol > tmp) {                                                                                    // 519
                nextCol = tmp;                                                                                        // 520
              }                                                                                                       //
                                                                                                                      //
              // copy current col value into previous (in preparation for next iteration)                             //
              prevRow[j] = curCol;                                                                                    // 507
            }                                                                                                         //
                                                                                                                      //
            // copy last col value into previous (in preparation for next iteration)                                  //
            prevRow[j] = nextCol;                                                                                     // 504
          }                                                                                                           //
                                                                                                                      //
          return nextCol;                                                                                             // 531
        }                                                                                                             //
                                                                                                                      //
        return levenshtein;                                                                                           //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 30: [function (require, module, exports) {                                     //
      module.exports = function () {                                                                                  // 535
        function lines(str) {                                                                                         // 535
          if (str == null) return [];                                                                                 // 536
          return String(str).split(/\r\n?|\n/);                                                                       // 537
        }                                                                                                             //
                                                                                                                      //
        return lines;                                                                                                 //
      }();                                                                                                            //
    }, {}], 31: [function (require, module, exports) {                                                                //
      var pad = require('./pad');                                                                                     // 541
                                                                                                                      //
      module.exports = function () {                                                                                  // 543
        function lpad(str, length, padStr) {                                                                          // 543
          return pad(str, length, padStr);                                                                            // 544
        }                                                                                                             //
                                                                                                                      //
        return lpad;                                                                                                  //
      }();                                                                                                            //
    }, { "./pad": 39 }], 32: [function (require, module, exports) {                                                   //
      var pad = require('./pad');                                                                                     // 548
                                                                                                                      //
      module.exports = function () {                                                                                  // 550
        function lrpad(str, length, padStr) {                                                                         // 550
          return pad(str, length, padStr, 'both');                                                                    // 551
        }                                                                                                             //
                                                                                                                      //
        return lrpad;                                                                                                 //
      }();                                                                                                            //
    }, { "./pad": 39 }], 33: [function (require, module, exports) {                                                   //
      var makeString = require('./helper/makeString');                                                                // 555
      var defaultToWhiteSpace = require('./helper/defaultToWhiteSpace');                                              // 556
      var nativeTrimLeft = String.prototype.trimLeft;                                                                 // 557
                                                                                                                      //
      module.exports = function () {                                                                                  // 559
        function ltrim(str, characters) {                                                                             // 559
          str = makeString(str);                                                                                      // 560
          if (!characters && nativeTrimLeft) return nativeTrimLeft.call(str);                                         // 561
          characters = defaultToWhiteSpace(characters);                                                               // 562
          return str.replace(new RegExp('^' + characters + '+'), '');                                                 // 563
        }                                                                                                             //
                                                                                                                      //
        return ltrim;                                                                                                 //
      }();                                                                                                            //
    }, { "./helper/defaultToWhiteSpace": 16, "./helper/makeString": 20 }], 34: [function (require, module, exports) {
      var makeString = require('./helper/makeString');                                                                // 567
                                                                                                                      //
      module.exports = function (str, callback) {                                                                     // 569
        str = makeString(str);                                                                                        // 570
                                                                                                                      //
        if (str.length === 0 || typeof callback !== 'function') return str;                                           // 572
                                                                                                                      //
        return str.replace(/./g, callback);                                                                           // 574
      };                                                                                                              //
    }, { "./helper/makeString": 20 }], 35: [function (require, module, exports) {                                     //
      module.exports = function () {                                                                                  // 578
        function naturalCmp(str1, str2) {                                                                             // 578
          if (str1 == str2) return 0;                                                                                 // 579
          if (!str1) return -1;                                                                                       // 580
          if (!str2) return 1;                                                                                        // 581
                                                                                                                      //
          var cmpRegex = /(\.\d+|\d+|\D+)/g,                                                                          // 583
              tokens1 = String(str1).match(cmpRegex),                                                                 //
              tokens2 = String(str2).match(cmpRegex),                                                                 //
              count = Math.min(tokens1.length, tokens2.length);                                                       //
                                                                                                                      //
          for (var i = 0; i < count; i++) {                                                                           // 588
            var a = tokens1[i],                                                                                       // 589
                b = tokens2[i];                                                                                       //
                                                                                                                      //
            if (a !== b) {                                                                                            // 592
              var num1 = +a;                                                                                          // 593
              var num2 = +b;                                                                                          // 594
              if (num1 === num1 && num2 === num2) {                                                                   // 595
                return num1 > num2 ? 1 : -1;                                                                          // 596
              }                                                                                                       //
              return a < b ? -1 : 1;                                                                                  // 598
            }                                                                                                         //
          }                                                                                                           //
                                                                                                                      //
          if (tokens1.length != tokens2.length) return tokens1.length - tokens2.length;                               // 602
                                                                                                                      //
          return str1 < str2 ? -1 : 1;                                                                                // 605
        }                                                                                                             //
                                                                                                                      //
        return naturalCmp;                                                                                            //
      }();                                                                                                            //
    }, {}], 36: [function (require, module, exports) {                                                                //
      (function (window) {                                                                                            // 609
        var re = {                                                                                                    // 610
          not_string: /[^s]/,                                                                                         // 611
          number: /[diefg]/,                                                                                          // 612
          json: /[j]/,                                                                                                // 613
          not_json: /[^j]/,                                                                                           // 614
          text: /^[^\x25]+/,                                                                                          // 615
          modulo: /^\x25{2}/,                                                                                         // 616
          placeholder: /^\x25(?:([1-9]\d*)\$|\(([^\)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-gijosuxX])/,      // 617
          key: /^([a-z_][a-z_\d]*)/i,                                                                                 // 618
          key_access: /^\.([a-z_][a-z_\d]*)/i,                                                                        // 619
          index_access: /^\[(\d+)\]/,                                                                                 // 620
          sign: /^[\+\-]/                                                                                             // 621
        };                                                                                                            //
                                                                                                                      //
        function sprintf() {                                                                                          // 624
          var key = arguments[0],                                                                                     // 625
              cache = sprintf.cache;                                                                                  //
          if (!(cache[key] && cache.hasOwnProperty(key))) {                                                           // 626
            cache[key] = sprintf.parse(key);                                                                          // 627
          }                                                                                                           //
          return sprintf.format.call(null, cache[key], arguments);                                                    // 629
        }                                                                                                             //
                                                                                                                      //
        sprintf.format = function (parse_tree, argv) {                                                                // 632
          var cursor = 1,                                                                                             // 633
              tree_length = parse_tree.length,                                                                        //
              node_type = "",                                                                                         //
              arg,                                                                                                    //
              output = [],                                                                                            //
              i,                                                                                                      //
              k,                                                                                                      //
              match,                                                                                                  //
              pad,                                                                                                    //
              pad_character,                                                                                          //
              pad_length,                                                                                             //
              is_positive = true,                                                                                     //
              sign = "";                                                                                              //
          for (i = 0; i < tree_length; i++) {                                                                         // 634
            node_type = get_type(parse_tree[i]);                                                                      // 635
            if (node_type === "string") {                                                                             // 636
              output[output.length] = parse_tree[i];                                                                  // 637
            } else if (node_type === "array") {                                                                       //
              match = parse_tree[i]; // convenience purposes only                                                     // 640
              if (match[2]) {                                                                                         // 639
                // keyword argument                                                                                   //
                arg = argv[cursor];                                                                                   // 642
                for (k = 0; k < match[2].length; k++) {                                                               // 643
                  if (!arg.hasOwnProperty(match[2][k])) {                                                             // 644
                    throw new Error(sprintf("[sprintf] property '%s' does not exist", match[2][k]));                  // 645
                  }                                                                                                   //
                  arg = arg[match[2][k]];                                                                             // 647
                }                                                                                                     //
              } else if (match[1]) {                                                                                  //
                // positional argument (explicit)                                                                     //
                arg = argv[match[1]];                                                                                 // 651
              } else {                                                                                                //
                // positional argument (implicit)                                                                     //
                arg = argv[cursor++];                                                                                 // 654
              }                                                                                                       //
                                                                                                                      //
              if (get_type(arg) == "function") {                                                                      // 657
                arg = arg();                                                                                          // 658
              }                                                                                                       //
                                                                                                                      //
              if (re.not_string.test(match[8]) && re.not_json.test(match[8]) && get_type(arg) != "number" && isNaN(arg)) {
                throw new TypeError(sprintf("[sprintf] expecting number but found %s", get_type(arg)));               // 662
              }                                                                                                       //
                                                                                                                      //
              if (re.number.test(match[8])) {                                                                         // 665
                is_positive = arg >= 0;                                                                               // 666
              }                                                                                                       //
                                                                                                                      //
              switch (match[8]) {                                                                                     // 669
                case "b":                                                                                             // 670
                  arg = arg.toString(2);                                                                              // 671
                  break;                                                                                              // 672
                case "c":                                                                                             // 669
                  arg = String.fromCharCode(arg);                                                                     // 674
                  break;                                                                                              // 675
                case "d":                                                                                             // 669
                case "i":                                                                                             // 677
                  arg = parseInt(arg, 10);                                                                            // 678
                  break;                                                                                              // 679
                case "j":                                                                                             // 669
                  arg = JSON.stringify(arg, null, match[6] ? parseInt(match[6]) : 0);                                 // 681
                  break;                                                                                              // 682
                case "e":                                                                                             // 669
                  arg = match[7] ? arg.toExponential(match[7]) : arg.toExponential();                                 // 684
                  break;                                                                                              // 685
                case "f":                                                                                             // 669
                  arg = match[7] ? parseFloat(arg).toFixed(match[7]) : parseFloat(arg);                               // 687
                  break;                                                                                              // 688
                case "g":                                                                                             // 669
                  arg = match[7] ? parseFloat(arg).toPrecision(match[7]) : parseFloat(arg);                           // 690
                  break;                                                                                              // 691
                case "o":                                                                                             // 669
                  arg = arg.toString(8);                                                                              // 693
                  break;                                                                                              // 694
                case "s":                                                                                             // 669
                  arg = (arg = String(arg)) && match[7] ? arg.substring(0, match[7]) : arg;                           // 696
                  break;                                                                                              // 697
                case "u":                                                                                             // 669
                  arg = arg >>> 0;                                                                                    // 699
                  break;                                                                                              // 700
                case "x":                                                                                             // 669
                  arg = arg.toString(16);                                                                             // 702
                  break;                                                                                              // 703
                case "X":                                                                                             // 669
                  arg = arg.toString(16).toUpperCase();                                                               // 705
                  break;                                                                                              // 706
              }                                                                                                       // 669
              if (re.json.test(match[8])) {                                                                           // 708
                output[output.length] = arg;                                                                          // 709
              } else {                                                                                                //
                if (re.number.test(match[8]) && (!is_positive || match[3])) {                                         // 712
                  sign = is_positive ? "+" : "-";                                                                     // 713
                  arg = arg.toString().replace(re.sign, "");                                                          // 714
                } else {                                                                                              //
                  sign = "";                                                                                          // 717
                }                                                                                                     //
                pad_character = match[4] ? match[4] === "0" ? "0" : match[4].charAt(1) : " ";                         // 719
                pad_length = match[6] - (sign + arg).length;                                                          // 720
                pad = match[6] ? pad_length > 0 ? str_repeat(pad_character, pad_length) : "" : "";                    // 721
                output[output.length] = match[5] ? sign + arg + pad : pad_character === "0" ? sign + pad + arg : pad + sign + arg;
              }                                                                                                       //
            }                                                                                                         //
          }                                                                                                           //
          return output.join("");                                                                                     // 726
        };                                                                                                            //
                                                                                                                      //
        sprintf.cache = {};                                                                                           // 729
                                                                                                                      //
        sprintf.parse = function (fmt) {                                                                              // 731
          var _fmt = fmt,                                                                                             // 732
              match = [],                                                                                             //
              parse_tree = [],                                                                                        //
              arg_names = 0;                                                                                          //
          while (_fmt) {                                                                                              // 733
            if ((match = re.text.exec(_fmt)) !== null) {                                                              // 734
              parse_tree[parse_tree.length] = match[0];                                                               // 735
            } else if ((match = re.modulo.exec(_fmt)) !== null) {                                                     //
              parse_tree[parse_tree.length] = "%";                                                                    // 738
            } else if ((match = re.placeholder.exec(_fmt)) !== null) {                                                //
              if (match[2]) {                                                                                         // 741
                arg_names |= 1;                                                                                       // 742
                var field_list = [],                                                                                  // 743
                    replacement_field = match[2],                                                                     //
                    field_match = [];                                                                                 //
                if ((field_match = re.key.exec(replacement_field)) !== null) {                                        // 744
                  field_list[field_list.length] = field_match[1];                                                     // 745
                  while ((replacement_field = replacement_field.substring(field_match[0].length)) !== "") {           // 746
                    if ((field_match = re.key_access.exec(replacement_field)) !== null) {                             // 747
                      field_list[field_list.length] = field_match[1];                                                 // 748
                    } else if ((field_match = re.index_access.exec(replacement_field)) !== null) {                    //
                      field_list[field_list.length] = field_match[1];                                                 // 751
                    } else {                                                                                          //
                      throw new SyntaxError("[sprintf] failed to parse named argument key");                          // 754
                    }                                                                                                 //
                  }                                                                                                   //
                } else {                                                                                              //
                  throw new SyntaxError("[sprintf] failed to parse named argument key");                              // 759
                }                                                                                                     //
                match[2] = field_list;                                                                                // 761
              } else {                                                                                                //
                arg_names |= 2;                                                                                       // 764
              }                                                                                                       //
              if (arg_names === 3) {                                                                                  // 766
                throw new Error("[sprintf] mixing positional and named placeholders is not (yet) supported");         // 767
              }                                                                                                       //
              parse_tree[parse_tree.length] = match;                                                                  // 769
            } else {                                                                                                  //
              throw new SyntaxError("[sprintf] unexpected placeholder");                                              // 772
            }                                                                                                         //
            _fmt = _fmt.substring(match[0].length);                                                                   // 774
          }                                                                                                           //
          return parse_tree;                                                                                          // 776
        };                                                                                                            //
                                                                                                                      //
        var vsprintf = function vsprintf(fmt, argv, _argv) {                                                          // 779
          _argv = (argv || []).slice(0);                                                                              // 780
          _argv.splice(0, 0, fmt);                                                                                    // 781
          return sprintf.apply(null, _argv);                                                                          // 782
        };                                                                                                            //
                                                                                                                      //
        /**                                                                                                           //
         * helpers                                                                                                    //
         */                                                                                                           //
        function get_type(variable) {                                                                                 // 609
          return Object.prototype.toString.call(variable).slice(8, -1).toLowerCase();                                 // 789
        }                                                                                                             //
                                                                                                                      //
        function str_repeat(input, multiplier) {                                                                      // 792
          return Array(multiplier + 1).join(input);                                                                   // 793
        }                                                                                                             //
                                                                                                                      //
        /**                                                                                                           //
         * export to either browser or node.js                                                                        //
         */                                                                                                           //
        if (typeof exports !== "undefined") {                                                                         // 609
          exports.sprintf = sprintf;                                                                                  // 800
          exports.vsprintf = vsprintf;                                                                                // 801
        } else {                                                                                                      //
          window.sprintf = sprintf;                                                                                   // 804
          window.vsprintf = vsprintf;                                                                                 // 805
                                                                                                                      //
          if (typeof define === "function" && define.amd) {                                                           // 807
            define(function () {                                                                                      // 808
              return {                                                                                                // 809
                sprintf: sprintf,                                                                                     // 810
                vsprintf: vsprintf                                                                                    // 811
              };                                                                                                      //
            });                                                                                                       //
          }                                                                                                           //
        }                                                                                                             //
      })(typeof window === "undefined" ? this : window);                                                              //
    }, {}], 37: [function (require, module, exports) {                                                                //
      (function (global) {                                                                                            // 819
                                                                                                                      //
        /**                                                                                                           //
         * Module exports.                                                                                            //
         */                                                                                                           //
                                                                                                                      //
        module.exports = deprecate;                                                                                   // 825
                                                                                                                      //
        /**                                                                                                           //
         * Mark that a method should not be used.                                                                     //
         * Returns a modified function which warns once by default.                                                   //
         *                                                                                                            //
         * If `localStorage.noDeprecation = true` is set, then it is a no-op.                                         //
         *                                                                                                            //
         * If `localStorage.throwDeprecation = true` is set, then deprecated functions                                //
         * will throw an Error when invoked.                                                                          //
         *                                                                                                            //
         * If `localStorage.traceDeprecation = true` is set, then deprecated functions                                //
         * will invoke `console.trace()` instead of `console.error()`.                                                //
         *                                                                                                            //
         * @param {Function} fn - the function to deprecate                                                           //
         * @param {String} msg - the string to print to the console when `fn` is invoked                              //
         * @returns {Function} a new "deprecated" version of `fn`                                                     //
         * @api public                                                                                                //
         */                                                                                                           //
                                                                                                                      //
        function deprecate(fn, msg) {                                                                                 // 819
          if (config('noDeprecation')) {                                                                              // 846
            return fn;                                                                                                // 847
          }                                                                                                           //
                                                                                                                      //
          var warned = false;                                                                                         // 850
          function deprecated() {                                                                                     // 851
            if (!warned) {                                                                                            // 852
              if (config('throwDeprecation')) {                                                                       // 853
                throw new Error(msg);                                                                                 // 854
              } else if (config('traceDeprecation')) {                                                                //
                console.trace(msg);                                                                                   // 856
              } else {                                                                                                //
                console.warn(msg);                                                                                    // 858
              }                                                                                                       //
              warned = true;                                                                                          // 860
            }                                                                                                         //
            return fn.apply(this, arguments);                                                                         // 862
          }                                                                                                           //
                                                                                                                      //
          return deprecated;                                                                                          // 865
        }                                                                                                             //
                                                                                                                      //
        /**                                                                                                           //
         * Checks `localStorage` for boolean values for the given `name`.                                             //
         *                                                                                                            //
         * @param {String} name                                                                                       //
         * @returns {Boolean}                                                                                         //
         * @api private                                                                                               //
         */                                                                                                           //
                                                                                                                      //
        function config(name) {                                                                                       // 819
          // accessing global.localStorage can trigger a DOMException in sandboxed iframes                            //
          try {                                                                                                       // 878
            if (!global.localStorage) return false;                                                                   // 879
          } catch (_) {                                                                                               //
            return false;                                                                                             // 881
          }                                                                                                           //
          var val = global.localStorage[name];                                                                        // 883
          if (null == val) return false;                                                                              // 884
          return String(val).toLowerCase() === 'true';                                                                // 885
        }                                                                                                             //
      }).call(this, typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
    }, {}], 38: [function (require, module, exports) {                                                                //
      module.exports = function () {                                                                                  // 890
        function numberFormat(number, dec, dsep, tsep) {                                                              // 890
          if (isNaN(number) || number == null) return '';                                                             // 891
                                                                                                                      //
          number = number.toFixed(~ ~dec);                                                                            // 893
          tsep = typeof tsep == 'string' ? tsep : ',';                                                                // 894
                                                                                                                      //
          var parts = number.split('.'),                                                                              // 896
              fnums = parts[0],                                                                                       //
              decimals = parts[1] ? (dsep || '.') + parts[1] : '';                                                    //
                                                                                                                      //
          return fnums.replace(/(\d)(?=(?:\d{3})+$)/g, '$1' + tsep) + decimals;                                       // 900
        }                                                                                                             //
                                                                                                                      //
        return numberFormat;                                                                                          //
      }();                                                                                                            //
    }, {}], 39: [function (require, module, exports) {                                                                //
      var makeString = require('./helper/makeString');                                                                // 904
      var strRepeat = require('./helper/strRepeat');                                                                  // 905
                                                                                                                      //
      module.exports = function () {                                                                                  // 907
        function pad(str, length, padStr, type) {                                                                     // 907
          str = makeString(str);                                                                                      // 908
          length = ~ ~length;                                                                                         // 909
                                                                                                                      //
          var padlen = 0;                                                                                             // 911
                                                                                                                      //
          if (!padStr) padStr = ' ';else if (padStr.length > 1) padStr = padStr.charAt(0);                            // 913
                                                                                                                      //
          switch (type) {                                                                                             // 918
            case 'right':                                                                                             // 919
              padlen = length - str.length;                                                                           // 920
              return str + strRepeat(padStr, padlen);                                                                 // 921
            case 'both':                                                                                              // 918
              padlen = length - str.length;                                                                           // 923
              return strRepeat(padStr, Math.ceil(padlen / 2)) + str + strRepeat(padStr, Math.floor(padlen / 2));      // 924
            default:                                                                                                  // 918
              // 'left'                                                                                               //
              padlen = length - str.length;                                                                           // 926
              return strRepeat(padStr, padlen) + str;                                                                 // 927
          }                                                                                                           // 918
        }                                                                                                             //
                                                                                                                      //
        return pad;                                                                                                   //
      }();                                                                                                            //
    }, { "./helper/makeString": 20, "./helper/strRepeat": 21 }], 40: [function (require, module, exports) {           //
      var adjacent = require('./helper/adjacent');                                                                    // 932
                                                                                                                      //
      module.exports = function () {                                                                                  // 934
        function succ(str) {                                                                                          // 934
          return adjacent(str, -1);                                                                                   // 935
        }                                                                                                             //
                                                                                                                      //
        return succ;                                                                                                  //
      }();                                                                                                            //
    }, { "./helper/adjacent": 15 }], 41: [function (require, module, exports) {                                       //
      /**                                                                                                             //
       * _s.prune: a more elegant version of truncate                                                                 //
       * prune extra chars, never leaving a half-chopped word.                                                        //
       * @author github.com/rwz                                                                                       //
       */                                                                                                             //
      var makeString = require('./helper/makeString');                                                                // 944
      var rtrim = require('./rtrim');                                                                                 // 945
                                                                                                                      //
      module.exports = function () {                                                                                  // 947
        function prune(str, length, pruneStr) {                                                                       // 947
          str = makeString(str);                                                                                      // 948
          length = ~ ~length;                                                                                         // 949
          pruneStr = pruneStr != null ? String(pruneStr) : '...';                                                     // 950
                                                                                                                      //
          if (str.length <= length) return str;                                                                       // 952
                                                                                                                      //
          var tmpl = function () {                                                                                    // 954
            function tmpl(c) {                                                                                        // 954
              return c.toUpperCase() !== c.toLowerCase() ? 'A' : ' ';                                                 // 955
            }                                                                                                         //
                                                                                                                      //
            return tmpl;                                                                                              //
          }(),                                                                                                        //
              template = str.slice(0, length + 1).replace(/.(?=\W*\w*$)/g, tmpl); // 'Hello, world' -> 'HellAA AAAAA'
                                                                                                                      //
          if (template.slice(template.length - 2).match(/\w\w/)) template = template.replace(/\s*\S+$/, '');else template = rtrim(template.slice(0, template.length - 1));
                                                                                                                      //
          return (template + pruneStr).length > str.length ? str : str.slice(0, template.length) + pruneStr;          // 964
        }                                                                                                             //
                                                                                                                      //
        return prune;                                                                                                 //
      }();                                                                                                            //
    }, { "./helper/makeString": 20, "./rtrim": 47 }], 42: [function (require, module, exports) {                      //
      var surround = require('./surround');                                                                           // 968
                                                                                                                      //
      module.exports = function () {                                                                                  // 970
        function quote(str, quoteChar) {                                                                              // 970
          return surround(str, quoteChar || '"');                                                                     // 971
        }                                                                                                             //
                                                                                                                      //
        return quote;                                                                                                 //
      }();                                                                                                            //
    }, { "./surround": 58 }], 43: [function (require, module, exports) {                                              //
      var makeString = require('./helper/makeString');                                                                // 975
      var strRepeat = require('./helper/strRepeat');                                                                  // 976
                                                                                                                      //
      module.exports = function () {                                                                                  // 978
        function repeat(str, qty, separator) {                                                                        // 978
          str = makeString(str);                                                                                      // 979
                                                                                                                      //
          qty = ~ ~qty;                                                                                               // 981
                                                                                                                      //
          // using faster implementation if separator is not needed;                                                  //
          if (separator == null) return strRepeat(str, qty);                                                          // 978
                                                                                                                      //
          // this one is about 300x slower in Google Chrome                                                           //
          /*eslint no-empty: 0*/                                                                                      //
          for (var repeat = []; qty > 0; repeat[--qty] = str) {}                                                      // 978
          return repeat.join(separator);                                                                              // 989
        }                                                                                                             //
                                                                                                                      //
        return repeat;                                                                                                //
      }();                                                                                                            //
    }, { "./helper/makeString": 20, "./helper/strRepeat": 21 }], 44: [function (require, module, exports) {           //
      var makeString = require('./helper/makeString');                                                                // 993
                                                                                                                      //
      module.exports = function () {                                                                                  // 995
        function replaceAll(str, find, replace, ignorecase) {                                                         // 995
          var flags = ignorecase === true ? 'gi' : 'g';                                                               // 996
          var reg = new RegExp(find, flags);                                                                          // 997
                                                                                                                      //
          return makeString(str).replace(reg, replace);                                                               // 999
        }                                                                                                             //
                                                                                                                      //
        return replaceAll;                                                                                            //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 45: [function (require, module, exports) {                                     //
      var chars = require('./chars');                                                                                 // 1003
                                                                                                                      //
      module.exports = function () {                                                                                  // 1005
        function reverse(str) {                                                                                       // 1005
          return chars(str).reverse().join('');                                                                       // 1006
        }                                                                                                             //
                                                                                                                      //
        return reverse;                                                                                               //
      }();                                                                                                            //
    }, { "./chars": 3 }], 46: [function (require, module, exports) {                                                  //
      var pad = require('./pad');                                                                                     // 1010
                                                                                                                      //
      module.exports = function () {                                                                                  // 1012
        function rpad(str, length, padStr) {                                                                          // 1012
          return pad(str, length, padStr, 'right');                                                                   // 1013
        }                                                                                                             //
                                                                                                                      //
        return rpad;                                                                                                  //
      }();                                                                                                            //
    }, { "./pad": 39 }], 47: [function (require, module, exports) {                                                   //
      var makeString = require('./helper/makeString');                                                                // 1017
      var defaultToWhiteSpace = require('./helper/defaultToWhiteSpace');                                              // 1018
      var nativeTrimRight = String.prototype.trimRight;                                                               // 1019
                                                                                                                      //
      module.exports = function () {                                                                                  // 1021
        function rtrim(str, characters) {                                                                             // 1021
          str = makeString(str);                                                                                      // 1022
          if (!characters && nativeTrimRight) return nativeTrimRight.call(str);                                       // 1023
          characters = defaultToWhiteSpace(characters);                                                               // 1024
          return str.replace(new RegExp(characters + '+$'), '');                                                      // 1025
        }                                                                                                             //
                                                                                                                      //
        return rtrim;                                                                                                 //
      }();                                                                                                            //
    }, { "./helper/defaultToWhiteSpace": 16, "./helper/makeString": 20 }], 48: [function (require, module, exports) {
      var trim = require('./trim');                                                                                   // 1029
      var dasherize = require('./dasherize');                                                                         // 1030
      var cleanDiacritics = require('./cleanDiacritics');                                                             // 1031
                                                                                                                      //
      module.exports = function () {                                                                                  // 1033
        function slugify(str) {                                                                                       // 1033
          return trim(dasherize(cleanDiacritics(str).replace(/[^\w\s-]/g, '-').toLowerCase()), '-');                  // 1034
        }                                                                                                             //
                                                                                                                      //
        return slugify;                                                                                               //
      }();                                                                                                            //
    }, { "./cleanDiacritics": 7, "./dasherize": 9, "./trim": 65 }], 49: [function (require, module, exports) {        //
      var chars = require('./chars');                                                                                 // 1038
                                                                                                                      //
      module.exports = function () {                                                                                  // 1040
        function splice(str, i, howmany, substr) {                                                                    // 1040
          var arr = chars(str);                                                                                       // 1041
          arr.splice(~ ~i, ~ ~howmany, substr);                                                                       // 1042
          return arr.join('');                                                                                        // 1043
        }                                                                                                             //
                                                                                                                      //
        return splice;                                                                                                //
      }();                                                                                                            //
    }, { "./chars": 3 }], 50: [function (require, module, exports) {                                                  //
      var deprecate = require('util-deprecate');                                                                      // 1047
                                                                                                                      //
      module.exports = deprecate(require('sprintf-js').sprintf, 'sprintf() will be removed in the next major release, use the sprintf-js package instead.');
    }, { "sprintf-js": 36, "util-deprecate": 37 }], 51: [function (require, module, exports) {                        //
      var makeString = require('./helper/makeString');                                                                // 1053
      var toPositive = require('./helper/toPositive');                                                                // 1054
                                                                                                                      //
      module.exports = function () {                                                                                  // 1056
        function startsWith(str, starts, position) {                                                                  // 1056
          str = makeString(str);                                                                                      // 1057
          starts = '' + starts;                                                                                       // 1058
          position = position == null ? 0 : Math.min(toPositive(position), str.length);                               // 1059
          return str.lastIndexOf(starts, position) === position;                                                      // 1060
        }                                                                                                             //
                                                                                                                      //
        return startsWith;                                                                                            //
      }();                                                                                                            //
    }, { "./helper/makeString": 20, "./helper/toPositive": 22 }], 52: [function (require, module, exports) {          //
      var makeString = require('./helper/makeString');                                                                // 1064
                                                                                                                      //
      module.exports = function () {                                                                                  // 1066
        function strLeft(str, sep) {                                                                                  // 1066
          str = makeString(str);                                                                                      // 1067
          sep = makeString(sep);                                                                                      // 1068
          var pos = !sep ? -1 : str.indexOf(sep);                                                                     // 1069
          return ~pos ? str.slice(0, pos) : str;                                                                      // 1070
        }                                                                                                             //
                                                                                                                      //
        return strLeft;                                                                                               //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 53: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 1074
                                                                                                                      //
      module.exports = function () {                                                                                  // 1076
        function strLeftBack(str, sep) {                                                                              // 1076
          str = makeString(str);                                                                                      // 1077
          sep = makeString(sep);                                                                                      // 1078
          var pos = str.lastIndexOf(sep);                                                                             // 1079
          return ~pos ? str.slice(0, pos) : str;                                                                      // 1080
        }                                                                                                             //
                                                                                                                      //
        return strLeftBack;                                                                                           //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 54: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 1084
                                                                                                                      //
      module.exports = function () {                                                                                  // 1086
        function strRight(str, sep) {                                                                                 // 1086
          str = makeString(str);                                                                                      // 1087
          sep = makeString(sep);                                                                                      // 1088
          var pos = !sep ? -1 : str.indexOf(sep);                                                                     // 1089
          return ~pos ? str.slice(pos + sep.length, str.length) : str;                                                // 1090
        }                                                                                                             //
                                                                                                                      //
        return strRight;                                                                                              //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 55: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 1094
                                                                                                                      //
      module.exports = function () {                                                                                  // 1096
        function strRightBack(str, sep) {                                                                             // 1096
          str = makeString(str);                                                                                      // 1097
          sep = makeString(sep);                                                                                      // 1098
          var pos = !sep ? -1 : str.lastIndexOf(sep);                                                                 // 1099
          return ~pos ? str.slice(pos + sep.length, str.length) : str;                                                // 1100
        }                                                                                                             //
                                                                                                                      //
        return strRightBack;                                                                                          //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 56: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 1104
                                                                                                                      //
      module.exports = function () {                                                                                  // 1106
        function stripTags(str) {                                                                                     // 1106
          return makeString(str).replace(/<\/?[^>]+>/g, '');                                                          // 1107
        }                                                                                                             //
                                                                                                                      //
        return stripTags;                                                                                             //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 57: [function (require, module, exports) {                                     //
      var adjacent = require('./helper/adjacent');                                                                    // 1111
                                                                                                                      //
      module.exports = function () {                                                                                  // 1113
        function succ(str) {                                                                                          // 1113
          return adjacent(str, 1);                                                                                    // 1114
        }                                                                                                             //
                                                                                                                      //
        return succ;                                                                                                  //
      }();                                                                                                            //
    }, { "./helper/adjacent": 15 }], 58: [function (require, module, exports) {                                       //
      module.exports = function () {                                                                                  // 1118
        function surround(str, wrapper) {                                                                             // 1118
          return [wrapper, str, wrapper].join('');                                                                    // 1119
        }                                                                                                             //
                                                                                                                      //
        return surround;                                                                                              //
      }();                                                                                                            //
    }, {}], 59: [function (require, module, exports) {                                                                //
      var makeString = require('./helper/makeString');                                                                // 1123
                                                                                                                      //
      module.exports = function () {                                                                                  // 1125
        function swapCase(str) {                                                                                      // 1125
          return makeString(str).replace(/\S/g, function (c) {                                                        // 1126
            return c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase();                                         // 1127
          });                                                                                                         //
        }                                                                                                             //
                                                                                                                      //
        return swapCase;                                                                                              //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 60: [function (require, module, exports) {                                     //
      var makeString = require('./helper/makeString');                                                                // 1132
                                                                                                                      //
      module.exports = function () {                                                                                  // 1134
        function titleize(str) {                                                                                      // 1134
          return makeString(str).toLowerCase().replace(/(?:^|\s|-)\S/g, function (c) {                                // 1135
            return c.toUpperCase();                                                                                   // 1136
          });                                                                                                         //
        }                                                                                                             //
                                                                                                                      //
        return titleize;                                                                                              //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 61: [function (require, module, exports) {                                     //
      var trim = require('./trim');                                                                                   // 1141
                                                                                                                      //
      function boolMatch(s, matchers) {                                                                               // 1143
        var i,                                                                                                        // 1144
            matcher,                                                                                                  //
            down = s.toLowerCase();                                                                                   //
        matchers = [].concat(matchers);                                                                               // 1145
        for (i = 0; i < matchers.length; i += 1) {                                                                    // 1146
          matcher = matchers[i];                                                                                      // 1147
          if (!matcher) continue;                                                                                     // 1148
          if (matcher.test && matcher.test(s)) return true;                                                           // 1149
          if (matcher.toLowerCase() === down) return true;                                                            // 1150
        }                                                                                                             //
      }                                                                                                               //
                                                                                                                      //
      module.exports = function () {                                                                                  // 1154
        function toBoolean(str, trueValues, falseValues) {                                                            // 1154
          if (typeof str === 'number') str = '' + str;                                                                // 1155
          if (typeof str !== 'string') return !!str;                                                                  // 1156
          str = trim(str);                                                                                            // 1157
          if (boolMatch(str, trueValues || ['true', '1'])) return true;                                               // 1158
          if (boolMatch(str, falseValues || ['false', '0'])) return false;                                            // 1159
        }                                                                                                             //
                                                                                                                      //
        return toBoolean;                                                                                             //
      }();                                                                                                            //
    }, { "./trim": 65 }], 62: [function (require, module, exports) {                                                  //
      module.exports = function () {                                                                                  // 1163
        function toNumber(num, precision) {                                                                           // 1163
          if (num == null) return 0;                                                                                  // 1164
          var factor = Math.pow(10, isFinite(precision) ? precision : 0);                                             // 1165
          return Math.round(num * factor) / factor;                                                                   // 1166
        }                                                                                                             //
                                                                                                                      //
        return toNumber;                                                                                              //
      }();                                                                                                            //
    }, {}], 63: [function (require, module, exports) {                                                                //
      var rtrim = require('./rtrim');                                                                                 // 1170
                                                                                                                      //
      module.exports = function () {                                                                                  // 1172
        function toSentence(array, separator, lastSeparator, serial) {                                                // 1172
          separator = separator || ', ';                                                                              // 1173
          lastSeparator = lastSeparator || ' and ';                                                                   // 1174
          var a = array.slice(),                                                                                      // 1175
              lastMember = a.pop();                                                                                   //
                                                                                                                      //
          if (array.length > 2 && serial) lastSeparator = rtrim(separator) + lastSeparator;                           // 1178
                                                                                                                      //
          return a.length ? a.join(separator) + lastSeparator + lastMember : lastMember;                              // 1180
        }                                                                                                             //
                                                                                                                      //
        return toSentence;                                                                                            //
      }();                                                                                                            //
    }, { "./rtrim": 47 }], 64: [function (require, module, exports) {                                                 //
      var toSentence = require('./toSentence');                                                                       // 1184
                                                                                                                      //
      module.exports = function () {                                                                                  // 1186
        function toSentenceSerial(array, sep, lastSep) {                                                              // 1186
          return toSentence(array, sep, lastSep, true);                                                               // 1187
        }                                                                                                             //
                                                                                                                      //
        return toSentenceSerial;                                                                                      //
      }();                                                                                                            //
    }, { "./toSentence": 63 }], 65: [function (require, module, exports) {                                            //
      var makeString = require('./helper/makeString');                                                                // 1191
      var defaultToWhiteSpace = require('./helper/defaultToWhiteSpace');                                              // 1192
      var nativeTrim = String.prototype.trim;                                                                         // 1193
                                                                                                                      //
      module.exports = function () {                                                                                  // 1195
        function trim(str, characters) {                                                                              // 1195
          str = makeString(str);                                                                                      // 1196
          if (!characters && nativeTrim) return nativeTrim.call(str);                                                 // 1197
          characters = defaultToWhiteSpace(characters);                                                               // 1198
          return str.replace(new RegExp('^' + characters + '+|' + characters + '+$', 'g'), '');                       // 1199
        }                                                                                                             //
                                                                                                                      //
        return trim;                                                                                                  //
      }();                                                                                                            //
    }, { "./helper/defaultToWhiteSpace": 16, "./helper/makeString": 20 }], 66: [function (require, module, exports) {
      var makeString = require('./helper/makeString');                                                                // 1203
                                                                                                                      //
      module.exports = function () {                                                                                  // 1205
        function truncate(str, length, truncateStr) {                                                                 // 1205
          str = makeString(str);                                                                                      // 1206
          truncateStr = truncateStr || '...';                                                                         // 1207
          length = ~ ~length;                                                                                         // 1208
          return str.length > length ? str.slice(0, length) + truncateStr : str;                                      // 1209
        }                                                                                                             //
                                                                                                                      //
        return truncate;                                                                                              //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }], 67: [function (require, module, exports) {                                     //
      var trim = require('./trim');                                                                                   // 1213
                                                                                                                      //
      module.exports = function () {                                                                                  // 1215
        function underscored(str) {                                                                                   // 1215
          return trim(str).replace(/([a-z\d])([A-Z]+)/g, '$1_$2').replace(/[-\s]+/g, '_').toLowerCase();              // 1216
        }                                                                                                             //
                                                                                                                      //
        return underscored;                                                                                           //
      }();                                                                                                            //
    }, { "./trim": 65 }], 68: [function (require, module, exports) {                                                  //
      var makeString = require('./helper/makeString');                                                                // 1220
      var htmlEntities = require('./helper/htmlEntities');                                                            // 1221
                                                                                                                      //
      module.exports = function () {                                                                                  // 1223
        function unescapeHTML(str) {                                                                                  // 1223
          return makeString(str).replace(/\&([^;]+);/g, function (entity, entityCode) {                               // 1224
            var match;                                                                                                // 1225
                                                                                                                      //
            if (entityCode in htmlEntities) {                                                                         // 1227
              return htmlEntities[entityCode];                                                                        // 1228
              /*eslint no-cond-assign: 0*/                                                                            //
            } else if (match = entityCode.match(/^#x([\da-fA-F]+)$/)) {                                               // 1227
                return String.fromCharCode(parseInt(match[1], 16));                                                   // 1231
                /*eslint no-cond-assign: 0*/                                                                          //
              } else if (match = entityCode.match(/^#(\d+)$/)) {                                                      // 1230
                  return String.fromCharCode(~ ~match[1]);                                                            // 1234
                } else {                                                                                              //
                  return entity;                                                                                      // 1236
                }                                                                                                     //
          });                                                                                                         //
        }                                                                                                             //
                                                                                                                      //
        return unescapeHTML;                                                                                          //
      }();                                                                                                            //
    }, { "./helper/htmlEntities": 19, "./helper/makeString": 20 }], 69: [function (require, module, exports) {        //
      module.exports = function () {                                                                                  // 1242
        function unquote(str, quoteChar) {                                                                            // 1242
          quoteChar = quoteChar || '"';                                                                               // 1243
          if (str[0] === quoteChar && str[str.length - 1] === quoteChar) return str.slice(1, str.length - 1);else return str;
        }                                                                                                             //
                                                                                                                      //
        return unquote;                                                                                               //
      }();                                                                                                            //
    }, {}], 70: [function (require, module, exports) {                                                                //
      var deprecate = require('util-deprecate');                                                                      // 1250
                                                                                                                      //
      module.exports = deprecate(require('sprintf-js').vsprintf, 'vsprintf() will be removed in the next major release, use the sprintf-js package instead.');
    }, { "sprintf-js": 36, "util-deprecate": 37 }], 71: [function (require, module, exports) {                        //
      var isBlank = require('./isBlank');                                                                             // 1256
      var trim = require('./trim');                                                                                   // 1257
                                                                                                                      //
      module.exports = function () {                                                                                  // 1259
        function words(str, delimiter) {                                                                              // 1259
          if (isBlank(str)) return [];                                                                                // 1260
          return trim(str, delimiter).split(delimiter || /\s+/);                                                      // 1261
        }                                                                                                             //
                                                                                                                      //
        return words;                                                                                                 //
      }();                                                                                                            //
    }, { "./isBlank": 27, "./trim": 65 }], 72: [function (require, module, exports) {                                 //
      // Wrap                                                                                                         //
      // wraps a string by a certain width                                                                            //
                                                                                                                      //
      var makeString = require('./helper/makeString');                                                                // 1268
                                                                                                                      //
      module.exports = function () {                                                                                  // 1270
        function wrap(str, options) {                                                                                 // 1270
          str = makeString(str);                                                                                      // 1271
                                                                                                                      //
          options = options || {};                                                                                    // 1273
                                                                                                                      //
          var width = options.width || 75;                                                                            // 1275
          var seperator = options.seperator || '\n';                                                                  // 1276
          var cut = options.cut || false;                                                                             // 1277
          var preserveSpaces = options.preserveSpaces || false;                                                       // 1278
          var trailingSpaces = options.trailingSpaces || false;                                                       // 1279
                                                                                                                      //
          var result;                                                                                                 // 1281
                                                                                                                      //
          if (width <= 0) {                                                                                           // 1283
            return str;                                                                                               // 1284
          } else if (!cut) {                                                                                          //
                                                                                                                      //
            var words = str.split(' ');                                                                               // 1289
            var current_column = 0;                                                                                   // 1290
            result = '';                                                                                              // 1291
                                                                                                                      //
            while (words.length > 0) {                                                                                // 1293
                                                                                                                      //
              // if adding a space and the next word would cause this line to be longer than width...                 //
              if (1 + words[0].length + current_column > width) {                                                     // 1296
                //start a new line if this line is not already empty                                                  //
                if (current_column > 0) {                                                                             // 1298
                  // add a space at the end of the line is preserveSpaces is true                                     //
                  if (preserveSpaces) {                                                                               // 1300
                    result += ' ';                                                                                    // 1301
                    current_column++;                                                                                 // 1302
                  }                                                                                                   //
                  // fill the rest of the line with spaces if trailingSpaces option is true                           //
                  else if (trailingSpaces) {                                                                          // 1300
                      while (current_column < width) {                                                                // 1306
                        result += ' ';                                                                                // 1307
                        current_column++;                                                                             // 1308
                      }                                                                                               //
                    }                                                                                                 //
                  //start new line                                                                                    //
                  result += seperator;                                                                                // 1298
                  current_column = 0;                                                                                 // 1313
                }                                                                                                     //
              }                                                                                                       //
                                                                                                                      //
              // if not at the begining of the line, add a space in front of the word                                 //
              if (current_column > 0) {                                                                               // 1293
                result += ' ';                                                                                        // 1319
                current_column++;                                                                                     // 1320
              }                                                                                                       //
                                                                                                                      //
              // tack on the next word, update current column, a pop words array                                      //
              result += words[0];                                                                                     // 1293
              current_column += words[0].length;                                                                      // 1325
              words.shift();                                                                                          // 1326
            }                                                                                                         //
                                                                                                                      //
            // fill the rest of the line with spaces if trailingSpaces option is true                                 //
            if (trailingSpaces) {                                                                                     // 1287
              while (current_column < width) {                                                                        // 1332
                result += ' ';                                                                                        // 1333
                current_column++;                                                                                     // 1334
              }                                                                                                       //
            }                                                                                                         //
                                                                                                                      //
            return result;                                                                                            // 1338
          } else {                                                                                                    //
                                                                                                                      //
            var index = 0;                                                                                            // 1344
            result = '';                                                                                              // 1345
                                                                                                                      //
            // walk through each character and add seperators where appropriate                                       //
            while (index < str.length) {                                                                              // 1342
              if (index % width == 0 && index > 0) {                                                                  // 1349
                result += seperator;                                                                                  // 1350
              }                                                                                                       //
              result += str.charAt(index);                                                                            // 1352
              index++;                                                                                                // 1353
            }                                                                                                         //
                                                                                                                      //
            // fill the rest of the line with spaces if trailingSpaces option is true                                 //
            if (trailingSpaces) {                                                                                     // 1342
              while (index % width > 0) {                                                                             // 1358
                result += ' ';                                                                                        // 1359
                index++;                                                                                              // 1360
              }                                                                                                       //
            }                                                                                                         //
                                                                                                                      //
            return result;                                                                                            // 1364
          }                                                                                                           //
        }                                                                                                             //
                                                                                                                      //
        return wrap;                                                                                                  //
      }();                                                                                                            //
    }, { "./helper/makeString": 20 }] }, {}, [25])(25);                                                               //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"_namespace":{"_namespaces.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/_namespace/_namespaces.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 12/31/14.                                                                                       //
 */                                                                                                                   //
                                                                                                                      //
/* global Collections: true, Controllers: true, ViewModels: true, Models: true */                                     //
                                                                                                                      //
// This file exists so that we can do "use strict" in all other files and                                             //
// still have some global namespace variables.                                                                        //
                                                                                                                      //
// It is called what it's called and placed where it's placed so that it loads                                        //
// as early as possible.                                                                                              //
                                                                                                                      //
Collections = {                                                                                                       // 13
	Servers: new Mongo.Collection('servers'),                                                                            // 14
	Projects: new Mongo.Collection('projects'),                                                                          // 15
	Builds: new Mongo.Collection('builds'),                                                                              // 16
	MyBuildDisplay: new Mongo.Collection('myBuildDisplay')                                                               // 17
};                                                                                                                    //
                                                                                                                      //
Controllers = {};                                                                                                     // 20
ViewModels = {};                                                                                                      // 21
Models = {};                                                                                                          // 22
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"lib":{"_namespaces.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/lib/_namespaces.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/26/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
/* global Services: true */                                                                                           //
                                                                                                                      //
// This file exists so that we can do "use strict" in all other files and                                             //
// still have some global namespace variables.                                                                        //
                                                                                                                      //
// It is called what it's called and placed where it's placed so that it loads                                        //
// as early as possible.                                                                                              //
                                                                                                                      //
Services = {};                                                                                                        // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"builds":{"!controller.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/builds/!controller.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/1/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Controllers.Builds = function () {                                                                                    // 6
                                                                                                                      //
	//region Private                                                                                                     //
	function _transform(doc) {                                                                                           // 9
		return new Models.Build(doc);                                                                                       // 10
	}                                                                                                                    //
                                                                                                                      //
	//endregion                                                                                                          //
                                                                                                                      //
	function GetBuild(buildId) {                                                                                         // 6
		return Collections.Builds.findOne({ _id: buildId }, { transform: _transform });                                     // 16
	}                                                                                                                    //
                                                                                                                      //
	function GetActiveServerBuilds(serverId) {                                                                           // 19
		return Collections.Builds.find({ serverId: serverId, watcherCount: { $gt: 0 } }, { transform: _transform });        // 20
	}                                                                                                                    //
                                                                                                                      //
	function GetBuildByServiceId(serverId, serviceBuildId) {                                                             // 26
		return Collections.Builds.findOne({ serverId: serverId, serviceBuildId: serviceBuildId }, { transform: _transform });
	}                                                                                                                    //
                                                                                                                      //
	function GetRunningServerBuilds(serverId) {                                                                          // 33
		return Collections.Builds.find({ serverId: serverId, isBuilding: true }, { transform: _transform });                // 34
	}                                                                                                                    //
                                                                                                                      //
	function GetAllByProjectId(projectId) {                                                                              // 40
		return Collections.Builds.find({ projectId: projectId }, { transform: _transform });                                // 41
	}                                                                                                                    //
                                                                                                                      //
	function RemoveByServerId(serverId) {                                                                                // 44
		var builds = Collections.Builds.find({ serverId: serverId }, { fields: { _id: 1 } }).fetch();                       // 45
                                                                                                                      //
		builds.forEach(function (build) {                                                                                   // 47
			Controllers.MyBuildDisplay.onRemoveByBuildId(build._id);                                                           // 48
		});                                                                                                                 //
                                                                                                                      //
		console.log('Removing Builds');                                                                                     // 51
		Collections.Builds.remove({ serverId: serverId });                                                                  // 52
	}                                                                                                                    //
                                                                                                                      //
	function RemoveByBuildId(buildId) {                                                                                  // 55
		Collections.Builds.remove({ _id: buildId });                                                                        // 56
		Controllers.MyBuildDisplay.onRemoveByBuildId(buildId);                                                              // 57
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 60
		getBuild: GetBuild,                                                                                                 // 61
		getActiveServerBuilds: GetActiveServerBuilds,                                                                       // 62
		getBuildByServiceId: GetBuildByServiceId,                                                                           // 63
		getRunningServerBuilds: GetRunningServerBuilds,                                                                     // 64
                                                                                                                      //
		getAllByProjectId: GetAllByProjectId,                                                                               // 66
                                                                                                                      //
		onRemoveByServerId: RemoveByServerId,                                                                               // 68
		onRemoveByBuildId: RemoveByBuildId                                                                                  // 69
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"builds.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/builds/builds.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by imod on 4/29/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Collections.Builds.allow({                                                                                            // 6
	insert: function () {                                                                                                // 7
		function insert() {                                                                                                 // 7
			return false;                                                                                                      // 8
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
                                                                                                                      //
	update: function () {                                                                                                // 11
		function update(userId, doc, fieldNames, modifier) {                                                                // 11
			return false;                                                                                                      // 12
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 14
		function remove() {                                                                                                 // 14
			return false;                                                                                                      // 15
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
Meteor.methods({                                                                                                      // 19
	removeBuild: Controllers.Builds.onRemoveByBuildId                                                                    // 20
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/builds/publish.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by imod on 4/29/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Meteor.publish('builds', function () {                                                                                // 7
  return Collections.Builds.find();                                                                                   // 8
});                                                                                                                   //
                                                                                                                      //
Meteor.publish('displayedBuilds', function () {                                                                       // 11
  return Collections.Builds.find({ watchers: { $in: [this.userId] } });                                               // 12
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"build.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/build.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/7/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Models.Build = function (doc) {                                                                                       // 6
	this._doc = doc;                                                                                                     // 7
	if (!this._doc.displayCounter) {                                                                                     // 8
		this._doc.displayCounter = 0;                                                                                       // 9
	}                                                                                                                    //
	if (this._doc.isLastBuildSuccess === undefined) {                                                                    // 11
		this._doc.isLastBuildSuccess = true;                                                                                // 12
	}                                                                                                                    //
	if (this._doc.watchers === undefined) {                                                                              // 14
		this._doc.watchers = [];                                                                                            // 15
	}                                                                                                                    //
};                                                                                                                    //
                                                                                                                      //
Models.Build.prototype = {                                                                                            // 19
	//region Properties                                                                                                  //
	get _id() {                                                                                                          // 21
		return this._doc._id;                                                                                               // 22
	},                                                                                                                   //
                                                                                                                      //
	get serverId() {                                                                                                     // 25
		return this._doc.serverId;                                                                                          // 26
	},                                                                                                                   //
                                                                                                                      //
	get projectId() {                                                                                                    // 29
		return this._doc.projectId;                                                                                         // 30
	},                                                                                                                   //
	set projectId(value) {                                                                                               // 32
		this._doc.projectId = value;                                                                                        // 33
	},                                                                                                                   //
                                                                                                                      //
	get serviceBuildId() {                                                                                               // 36
		return this._doc.serviceBuildId;                                                                                    // 37
	},                                                                                                                   //
                                                                                                                      //
	get name() {                                                                                                         // 40
		return this._doc.name;                                                                                              // 41
	},                                                                                                                   //
                                                                                                                      //
	get href() {                                                                                                         // 44
		return this._doc.href;                                                                                              // 45
	},                                                                                                                   //
                                                                                                                      //
	get watchers() {                                                                                                     // 48
		return this._doc.watchers;                                                                                          // 49
	},                                                                                                                   //
                                                                                                                      //
	/**                                                                                                                  //
  * @returns {boolean}                                                                                                //
  */                                                                                                                  //
	get isDisplayed() {                                                                                                  // 55
		return this.watchers.length > 0;                                                                                    // 56
	},                                                                                                                   //
                                                                                                                      //
	/**                                                                                                                  //
  * @returns {boolean}                                                                                                //
  */                                                                                                                  //
	get isLastBuildSuccess() {                                                                                           // 62
		return this._doc.isLastBuildSuccess;                                                                                // 63
	},                                                                                                                   //
                                                                                                                      //
	/**                                                                                                                  //
  * @returns {boolean}                                                                                                //
  */                                                                                                                  //
	get isBuilding() {                                                                                                   // 69
		return this._doc.isBuilding;                                                                                        // 70
	},                                                                                                                   //
                                                                                                                      //
	get builds() {                                                                                                       // 73
		return this._doc.builds;                                                                                            // 74
	},                                                                                                                   //
	set builds(value) {                                                                                                  // 76
		this._doc.builds = value;                                                                                           // 77
	},                                                                                                                   //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	toJson: function () {                                                                                                // 82
		function toJson() {                                                                                                 // 82
			return this._doc;                                                                                                  // 83
		}                                                                                                                   //
                                                                                                                      //
		return toJson;                                                                                                      //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  *                                                                                                                   //
  * @param {Models.BuildDetail} buildDetail                                                                           //
  * @private                                                                                                          //
  */                                                                                                                  //
	_updateBuild: function () {                                                                                          // 91
		function _updateBuild(buildDetail) {                                                                                // 91
			// Ensure that our build was started.                                                                              //
			if (this.builds.length > 0 && this.builds[0].id !== buildDetail.id) {                                              // 93
				return;                                                                                                           // 94
			}                                                                                                                  //
                                                                                                                      //
			var set = {                                                                                                        // 97
				'builds.0.isBuilding': buildDetail.isBuilding,                                                                    // 98
				'builds.0.isSuccess': buildDetail.isSuccess,                                                                      // 99
				'builds.0.statusText': buildDetail.statusText,                                                                    // 100
				'builds.0.percentageComplete': buildDetail.percentageComplete                                                     // 101
			};                                                                                                                 //
                                                                                                                      //
			if (this.isLastBuildSuccess && !buildDetail.isSuccess) {                                                           // 104
				set.isLastBuildSuccess = false;                                                                                   // 105
				set.whoBrokeIt = buildDetail.usernames;                                                                           // 106
			}                                                                                                                  //
                                                                                                                      //
			Collections.Builds.update({ _id: this._id }, { $set: set });                                                       // 109
		}                                                                                                                   //
                                                                                                                      //
		return _updateBuild;                                                                                                //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  *                                                                                                                   //
  * @param {Models.BuildDetail} buildDetail                                                                           //
  * @private                                                                                                          //
  */                                                                                                                  //
	_finishBuild: function () {                                                                                          // 117
		function _finishBuild(buildDetail) {                                                                                // 117
			Collections.Builds.update({ _id: this._id }, {                                                                     // 118
				$set: {                                                                                                           // 119
					isLastBuildSuccess: buildDetail.isSuccess,                                                                       // 120
					isBuilding: false,                                                                                               // 121
					'builds.0.isBuilding': buildDetail.isBuilding,                                                                   // 122
					'builds.0.isSuccess': buildDetail.isSuccess,                                                                     // 123
					'builds.0.statusText': buildDetail.statusText,                                                                   // 124
					'builds.0.percentageComplete': buildDetail.percentageComplete,                                                   // 125
					'builds.0.finishDate': buildDetail.finishDate                                                                    // 126
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return _finishBuild;                                                                                                //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Refreshes the build history data for this build.                                                                  //
  *                                                                                                                   //
  * @param service                                                                                                    //
  */                                                                                                                  //
	refreshBuildData: function () {                                                                                      // 136
		function refreshBuildData(service) {                                                                                // 136
			var self = this;                                                                                                   // 137
			service.getBuildData(self.href, 10, function (buildDetailsArray) {                                                 // 138
				var isLastBuildSuccess = true,                                                                                    // 139
				    whoBrokeIt = null,                                                                                            //
				    isBuilding = false;                                                                                           //
				if (buildDetailsArray.length > 0) {                                                                               // 142
					isBuilding = buildDetailsArray[0].isBuilding;                                                                    // 143
                                                                                                                      //
					if (!buildDetailsArray[0].isSuccess) {                                                                           // 145
						isLastBuildSuccess = false;                                                                                     // 146
						whoBrokeIt = buildDetailsArray[0].usernames;                                                                    // 147
					} else if (isBuilding && buildDetailsArray.length > 1) {                                                         //
						isLastBuildSuccess = buildDetailsArray[1].isSuccess;                                                            // 149
						whoBrokeIt = buildDetailsArray[1].usernames;                                                                    // 150
					}                                                                                                                //
				}                                                                                                                 //
                                                                                                                      //
				var buildData = _.map(buildDetailsArray, function (bd) {                                                          // 154
					return bd.toJson();                                                                                              // 155
				});                                                                                                               //
                                                                                                                      //
				Collections.Builds.update({ _id: self._id }, {                                                                    // 158
					$set: {                                                                                                          // 159
						isLastBuildSuccess: isLastBuildSuccess,                                                                         // 160
						whoBrokeIt: whoBrokeIt,                                                                                         // 161
						builds: buildData,                                                                                              // 162
						isBuilding: isBuilding                                                                                          // 163
					}                                                                                                                //
				});                                                                                                               //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return refreshBuildData;                                                                                            //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Starts a new build for this buildType.                                                                            //
  *                                                                                                                   //
  * @param service                                                                                                    //
  * @param href                                                                                                       //
  */                                                                                                                  //
	startBuild: function () {                                                                                            // 175
		function startBuild(service, href) {                                                                                // 175
			var self = this;                                                                                                   // 176
			service.getBuildDetails(href, function (buildDetail) {                                                             // 177
				if (!self.builds) {                                                                                               // 178
					self.builds = [];                                                                                                // 179
				}                                                                                                                 //
                                                                                                                      //
				self.builds.splice(0, 0, buildDetail.toJson());                                                                   // 182
				while (self.builds.length > 10) {                                                                                 // 183
					self.builds.pop();                                                                                               // 184
				}                                                                                                                 //
                                                                                                                      //
				Collections.Builds.update({ _id: self._id }, { $set: { isBuilding: true, builds: self.builds } });                // 187
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return startBuild;                                                                                                  //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Updates the latest build information.                                                                             //
  *                                                                                                                   //
  * @param service                                                                                                    //
  */                                                                                                                  //
	updateRunningBuild: function () {                                                                                    // 196
		function updateRunningBuild(service) {                                                                              // 196
			var self = this,                                                                                                   // 197
			    build = self.builds[0];                                                                                        //
                                                                                                                      //
			if (!build.href) {                                                                                                 // 200
				return;                                                                                                           // 201
			}                                                                                                                  //
                                                                                                                      //
			service.getBuildDetails(build.href, function (buildDetail) {                                                       // 204
				self._updateBuild(buildDetail);                                                                                   // 205
				if (!buildDetail.isBuilding) {                                                                                    // 206
					self._finishBuild(buildDetail);                                                                                  // 207
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return updateRunningBuild;                                                                                          //
	}(),                                                                                                                 //
                                                                                                                      //
	addWatcher: function () {                                                                                            // 212
		function addWatcher(service, watcher) {                                                                             // 212
			if (_.contains(this.watchers, watcher)) {                                                                          // 213
				return;                                                                                                           // 214
			}                                                                                                                  //
                                                                                                                      //
			this._doc.watchers.push(watcher);                                                                                  // 217
			Collections.Builds.update({ _id: this._id }, {                                                                     // 218
				$addToSet: { watchers: watcher },                                                                                 // 219
				$set: { watcherCount: this.watchers.length }                                                                      // 220
			});                                                                                                                //
                                                                                                                      //
			if (this.watchers.length === 1 && service) {                                                                       // 223
				this.refreshBuildData(service);                                                                                   // 224
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return addWatcher;                                                                                                  //
	}(),                                                                                                                 //
                                                                                                                      //
	removeWatcher: function () {                                                                                         // 228
		function removeWatcher(watcher) {                                                                                   // 228
			var nWatchers = _.reject(this.watchers, function (w) {                                                             // 229
				return w === watcher;                                                                                             // 230
			});                                                                                                                //
                                                                                                                      //
			if (nWatchers.length === this.watchers.length) {                                                                   // 233
				return;                                                                                                           // 234
			}                                                                                                                  //
                                                                                                                      //
			this._doc.watchers = nWatchers;                                                                                    // 237
			Collections.Builds.update({ _id: this._id }, { $set: { watchers: nWatchers, watcherCount: this.watchers.length } });
		}                                                                                                                   //
                                                                                                                      //
		return removeWatcher;                                                                                               //
	}()                                                                                                                  //
	//endregion                                                                                                          //
};                                                                                                                    // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"buildDetail.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/buildDetail.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/7/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
/**                                                                                                                   //
 * A single change for this build.                                                                                    //
 *                                                                                                                    //
 * @param {{                                                                                                          //
 * id: number|string,                                                                                                 //
 * serviceBuildId: string,                                                                                            //
 * serviceNumber: string,                                                                                             //
 * isSuccess: boolean,                                                                                                //
 * isBuilding: boolean,                                                                                               //
 * href: string,                                                                                                      //
 * percentageComplete: Number,                                                                                        //
 * statusText: string,                                                                                                //
 * startDate: Date,                                                                                                   //
 * finishDate: Date,                                                                                                  //
 * usernames: string[]}} doc                                                                                          //
 *                                                                                                                    //
 * @constructor                                                                                                       //
 */                                                                                                                   //
                                                                                                                      //
Models.BuildDetail = function (doc) {                                                                                 // 25
	this.json = {                                                                                                        // 26
		id: doc.id,                                                                                                         // 27
		serviceBuildId: doc.serviceBuildId,                                                                                 // 28
		serviceNumber: doc.serviceNumber,                                                                                   // 29
		isSuccess: doc.isSuccess,                                                                                           // 30
		isBuilding: doc.isBuilding,                                                                                         // 31
		href: doc.href,                                                                                                     // 32
		percentageComplete: doc.percentageComplete,                                                                         // 33
		statusText: doc.statusText,                                                                                         // 34
		startDate: doc.startDate,                                                                                           // 35
		finishDate: doc.finishDate,                                                                                         // 36
		usernames: _.map(doc.usernames, function (user) {                                                                   // 37
			var u = new Models.Username(user);                                                                                 // 38
			return u.clean;                                                                                                    // 39
		})                                                                                                                  //
	};                                                                                                                   //
};                                                                                                                    //
                                                                                                                      //
Models.BuildDetail.prototype = {                                                                                      // 44
	//region Properties                                                                                                  //
	get id() {                                                                                                           // 46
		return this.json.id;                                                                                                // 47
	},                                                                                                                   //
                                                                                                                      //
	get serviceBuildId() {                                                                                               // 50
		return this.json.serviceBuildId;                                                                                    // 51
	},                                                                                                                   //
                                                                                                                      //
	get serviceNumber() {                                                                                                // 54
		return this.json.serviceNumber;                                                                                     // 55
	},                                                                                                                   //
                                                                                                                      //
	get isSuccess() {                                                                                                    // 58
		return this.json.isSuccess;                                                                                         // 59
	},                                                                                                                   //
                                                                                                                      //
	get isBuilding() {                                                                                                   // 62
		return this.json.isBuilding;                                                                                        // 63
	},                                                                                                                   //
                                                                                                                      //
	get href() {                                                                                                         // 66
		return this.json.href;                                                                                              // 67
	},                                                                                                                   //
                                                                                                                      //
	get percentageComplete() {                                                                                           // 70
		return this.json.percentageComplete;                                                                                // 71
	},                                                                                                                   //
                                                                                                                      //
	get statusText() {                                                                                                   // 74
		return this.json.statusText;                                                                                        // 75
	},                                                                                                                   //
                                                                                                                      //
	get startDate() {                                                                                                    // 78
		return this.json.startDate;                                                                                         // 79
	},                                                                                                                   //
                                                                                                                      //
	get finishDate() {                                                                                                   // 82
		return this.json.finishDate;                                                                                        // 83
	},                                                                                                                   //
                                                                                                                      //
	get changes() {                                                                                                      // 86
		return this.json.changes;                                                                                           // 87
	},                                                                                                                   //
                                                                                                                      //
	get usernames() {                                                                                                    // 90
		return this.json.usernames;                                                                                         // 91
	},                                                                                                                   //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	toJson: function () {                                                                                                // 96
		function toJson() {                                                                                                 // 96
			return this.json;                                                                                                  // 97
		}                                                                                                                   //
                                                                                                                      //
		return toJson;                                                                                                      //
	}()                                                                                                                  //
	//endregion                                                                                                          //
};                                                                                                                    // 44
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"buildSummary.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/buildSummary.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/9/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
/**                                                                                                                   //
 * A single change for this build.                                                                                    //
 *                                                                                                                    //
 * @param {{                                                                                                          //
 * id: number|string,                                                                                                 //
 * serviceBuildId: string,                                                                                            //
 * serviceNumber: string,                                                                                             //
 * isSuccess: boolean,                                                                                                //
 * isBuilding: boolean,                                                                                               //
 * href: string}} doc                                                                                                 //
 *                                                                                                                    //
 * @constructor                                                                                                       //
 */                                                                                                                   //
                                                                                                                      //
Models.BuildSummary = function (doc) {                                                                                // 19
	this.json = {                                                                                                        // 20
		id: doc.id,                                                                                                         // 21
		serviceBuildId: doc.serviceBuildId,                                                                                 // 22
		serviceNumber: doc.serviceNumber,                                                                                   // 23
		isSuccess: doc.isSuccess,                                                                                           // 24
		isBuilding: doc.isBuilding,                                                                                         // 25
		href: doc.href                                                                                                      // 26
	};                                                                                                                   //
};                                                                                                                    //
                                                                                                                      //
Models.BuildSummary.prototype = {                                                                                     // 30
	//region Properties                                                                                                  //
	get id() {                                                                                                           // 32
		return this.json.id;                                                                                                // 33
	},                                                                                                                   //
                                                                                                                      //
	get serviceBuildId() {                                                                                               // 36
		return this.json.serviceBuildId;                                                                                    // 37
	},                                                                                                                   //
                                                                                                                      //
	get serviceNumber() {                                                                                                // 40
		return this.json.serviceNumber;                                                                                     // 41
	},                                                                                                                   //
                                                                                                                      //
	get isSuccess() {                                                                                                    // 44
		return this.json.isSuccess;                                                                                         // 45
	},                                                                                                                   //
                                                                                                                      //
	get isBuilding() {                                                                                                   // 48
		return this.json.isBuilding;                                                                                        // 49
	},                                                                                                                   //
                                                                                                                      //
	get href() {                                                                                                         // 52
		return this.json.href;                                                                                              // 53
	},                                                                                                                   //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	toJson: function () {                                                                                                // 58
		function toJson() {                                                                                                 // 58
			return this.json;                                                                                                  // 59
		}                                                                                                                   //
                                                                                                                      //
		return toJson;                                                                                                      //
	}()                                                                                                                  //
	//endregion                                                                                                          //
};                                                                                                                    // 30
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"project.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/project.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/11/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
/**                                                                                                                   //
 * @param {{_id: string, serverId: string, serviceProjectId: string,                                                  //
 * serviceParentProjectId: string, name: string, href: string}} doc                                                   //
 * @constructor                                                                                                       //
 */                                                                                                                   //
                                                                                                                      //
Models.Project = function (doc) {                                                                                     // 11
	this._doc = doc;                                                                                                     // 12
};                                                                                                                    //
                                                                                                                      //
Models.Project.prototype = {                                                                                          // 15
	//region Properties                                                                                                  //
	get _id() {                                                                                                          // 17
		return this._doc._id;                                                                                               // 18
	},                                                                                                                   //
                                                                                                                      //
	get serverId() {                                                                                                     // 21
		return this._doc.serverId;                                                                                          // 22
	},                                                                                                                   //
                                                                                                                      //
	get parentId() {                                                                                                     // 25
		return this._doc.parentId;                                                                                          // 26
	},                                                                                                                   //
                                                                                                                      //
	get serviceProjectId() {                                                                                             // 29
		return this._doc.serviceProjectId;                                                                                  // 30
	},                                                                                                                   //
                                                                                                                      //
	get serviceParentProjectId() {                                                                                       // 33
		return this._doc.serviceParentProjectId;                                                                            // 34
	},                                                                                                                   //
                                                                                                                      //
	get name() {                                                                                                         // 37
		return this._doc.name;                                                                                              // 38
	},                                                                                                                   //
                                                                                                                      //
	get href() {                                                                                                         // 41
		return this._doc.href;                                                                                              // 42
	},                                                                                                                   //
                                                                                                                      //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	toJson: function () {                                                                                                // 48
		function toJson() {                                                                                                 // 48
			return this._doc;                                                                                                  // 49
		}                                                                                                                   //
                                                                                                                      //
		return toJson;                                                                                                      //
	}()                                                                                                                  //
	//endregion                                                                                                          //
};                                                                                                                    // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"server.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/server.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/7/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Models.Server = function (doc) {                                                                                      // 6
	this._doc = doc;                                                                                                     // 7
	this._service = Services.Factory.getService(this._doc);                                                              // 8
};                                                                                                                    //
                                                                                                                      //
Models.Server.prototype = {                                                                                           // 11
	//region Properties                                                                                                  //
	get service() {                                                                                                      // 13
		return this._service;                                                                                               // 14
	},                                                                                                                   //
                                                                                                                      //
	get _id() {                                                                                                          // 17
		return this._doc._id;                                                                                               // 18
	},                                                                                                                   //
                                                                                                                      //
	get name() {                                                                                                         // 21
		return this._doc.name;                                                                                              // 22
	},                                                                                                                   //
	set name(value) {                                                                                                    // 24
		this._doc.name = value;                                                                                             // 25
	},                                                                                                                   //
                                                                                                                      //
	get type() {                                                                                                         // 28
		return this._doc.type;                                                                                              // 29
	},                                                                                                                   //
	set type(value) {                                                                                                    // 31
		this._doc.type = value;                                                                                             // 32
	},                                                                                                                   //
                                                                                                                      //
	get url() {                                                                                                          // 35
		return this._doc.url;                                                                                               // 36
	},                                                                                                                   //
	set url(value) {                                                                                                     // 38
		this._doc.url = value;                                                                                              // 39
	},                                                                                                                   //
                                                                                                                      //
	get user() {                                                                                                         // 42
		return this._doc.user;                                                                                              // 43
	},                                                                                                                   //
	set user(value) {                                                                                                    // 45
		this._doc.user = value;                                                                                             // 46
	},                                                                                                                   //
                                                                                                                      //
	get password() {                                                                                                     // 49
		return this._doc.password;                                                                                          // 50
	},                                                                                                                   //
	set password(value) {                                                                                                // 52
		this._doc.password = value;                                                                                         // 53
	},                                                                                                                   //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	toJson: function () {                                                                                                // 58
		function toJson() {                                                                                                 // 58
			return this._doc;                                                                                                  // 59
		}                                                                                                                   //
                                                                                                                      //
		return toJson;                                                                                                      //
	}(),                                                                                                                 //
                                                                                                                      //
	save: function () {                                                                                                  // 62
		function save(cb) {                                                                                                 // 62
			var updData = {                                                                                                    // 63
				name: this.name,                                                                                                  // 64
				type: 'teamcity',                                                                                                 // 65
				url: this.url,                                                                                                    // 66
				user: this.user,                                                                                                  // 67
				password: this.password                                                                                           // 68
			};                                                                                                                 //
                                                                                                                      //
			if (this._id) {                                                                                                    // 71
				return Collections.Servers.update({ _id: this._id }, { $set: updData });                                          // 72
			}                                                                                                                  //
                                                                                                                      //
			return Collections.Servers.insert(updData);                                                                        // 75
		}                                                                                                                   //
                                                                                                                      //
		return save;                                                                                                        //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Refreshes the projects from the server.                                                                           //
  */                                                                                                                  //
	refreshProjects: function () {                                                                                       // 81
		function refreshProjects() {                                                                                        // 81
			this.service.getProjects(Controllers.Projects.onAddProject);                                                       // 82
		}                                                                                                                   //
                                                                                                                      //
		return refreshProjects;                                                                                             //
	}(),                                                                                                                 //
                                                                                                                      //
	toggleBuildDisplay: function () {                                                                                    // 85
		function toggleBuildDisplay(buildId, watcher, isDisplayed) {                                                        // 85
			var build = Controllers.Builds.getBuild(buildId);                                                                  // 86
			if (isDisplayed) {                                                                                                 // 87
				build.addWatcher(this._service, watcher);                                                                         // 88
			} else {                                                                                                           //
				build.removeWatcher(watcher);                                                                                     // 90
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return toggleBuildDisplay;                                                                                          //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Refreshes the build history data for all the active builds.                                                       //
  */                                                                                                                  //
	refreshActiveBuildData: function () {                                                                                // 97
		function refreshActiveBuildData() {                                                                                 // 97
			var self = this;                                                                                                   // 98
			var builds = Controllers.Builds.getActiveServerBuilds(this._id);                                                   // 99
			builds.forEach(function (build) {                                                                                  // 100
				build.refreshBuildData(self._service);                                                                            // 101
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return refreshActiveBuildData;                                                                                      //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Refreshes the build history data for a single build.                                                              //
  *                                                                                                                   //
  * @param buildId                                                                                                    //
  */                                                                                                                  //
	refreshBuildData: function () {                                                                                      // 110
		function refreshBuildData(buildId) {                                                                                // 110
			var build = Controllers.Builds.getBuild(buildId);                                                                  // 111
			build.refreshBuildData(this._service);                                                                             // 112
		}                                                                                                                   //
                                                                                                                      //
		return refreshBuildData;                                                                                            //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Queries the server for any running builds.                                                                        //
  *                                                                                                                   //
  * @param {Function} cbTimerUpdate                                                                                   //
  */                                                                                                                  //
	queryRunningBuilds: function () {                                                                                    // 120
		function queryRunningBuilds(cbTimerUpdate) {                                                                        // 120
			var self = this;                                                                                                   // 121
			this._service.queryRunningBuilds(function (builds) {                                                               // 122
				if (builds.length === 0) {                                                                                        // 123
					self.updateRunningBuilds();                                                                                      // 124
					return cbTimerUpdate(self._id, false);                                                                           // 125
				}                                                                                                                 //
                                                                                                                      //
				builds.forEach(function (build) {                                                                                 // 128
					var bm = Controllers.Builds.getBuildByServiceId(self._id, build.serviceBuildId);                                 // 129
					if (bm && !bm.isBuilding) {                                                                                      // 130
						bm.startBuild(self._service, build.href);                                                                       // 131
					}                                                                                                                //
				});                                                                                                               //
                                                                                                                      //
				cbTimerUpdate(self._id, true);                                                                                    // 135
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return queryRunningBuilds;                                                                                          //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Updates the running builds from the server.                                                                       //
  */                                                                                                                  //
	updateRunningBuilds: function () {                                                                                   // 142
		function updateRunningBuilds(cbTimerUpdate) {                                                                       // 142
			var self = this,                                                                                                   // 143
			    builds = Controllers.Builds.getRunningServerBuilds(self._id),                                                  //
			    hasRunningBuilds = false;                                                                                      //
                                                                                                                      //
			builds.forEach(function (build) {                                                                                  // 147
				hasRunningBuilds = true;                                                                                          // 148
				build.updateRunningBuild(self._service);                                                                          // 149
			});                                                                                                                //
                                                                                                                      //
			if (!hasRunningBuilds && cbTimerUpdate !== undefined) {                                                            // 152
				cbTimerUpdate(self._id, false);                                                                                   // 153
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return updateRunningBuilds;                                                                                         //
	}()                                                                                                                  //
	//endregion                                                                                                          //
};                                                                                                                    // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"username.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/models/username.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 5/7/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
function cleanUsername(username) {                                                                                    // 6
	var clean = username,                                                                                                // 7
	    idx = username.indexOf('\\');                                                                                    //
                                                                                                                      //
	if (idx > -1) {                                                                                                      // 10
		clean = clean.substr(idx + 1);                                                                                      // 11
	}                                                                                                                    //
                                                                                                                      //
	idx = clean.indexOf('<');                                                                                            // 14
	if (idx > -1) {                                                                                                      // 15
		clean = clean.substr(0, idx);                                                                                       // 16
	}                                                                                                                    //
                                                                                                                      //
	return clean.trim();                                                                                                 // 19
}                                                                                                                     //
                                                                                                                      //
Models.Username = function (username) {                                                                               // 22
	this._raw = username;                                                                                                // 23
	this._clean = cleanUsername(username);                                                                               // 24
};                                                                                                                    //
                                                                                                                      //
Models.Username.prototype = {                                                                                         // 27
	//region Properties                                                                                                  //
	get raw() {                                                                                                          // 29
		return this._raw;                                                                                                   // 30
	},                                                                                                                   //
	get clean() {                                                                                                        // 32
		return this._clean;                                                                                                 // 33
	}                                                                                                                    //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	//endregion                                                                                                          //
};                                                                                                                    // 27
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"myBuildDisplay":{"controller.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/myBuildDisplay/controller.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Controllers.MyBuildDisplay = function () {                                                                            // 2
	function GetBuildDisplayCount(buildId) {                                                                             // 3
		return Collections.Builds.find({ _id: buildId }, { fields: { _id: 1 } }).count();                                   // 4
	}                                                                                                                    //
                                                                                                                      //
	function RemoveByBuildId(buildId) {                                                                                  // 7
		Collections.MyBuildDisplay.remove({ buildId: buildId });                                                            // 8
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 11
		onGetBuildDisplayCount: GetBuildDisplayCount,                                                                       // 12
		onRemoveByBuildId: RemoveByBuildId                                                                                  // 13
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"myBuildDisplay.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/myBuildDisplay/myBuildDisplay.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Controllers.MyBuildDisplayAllow = function () {                                                                       // 2
	function Insert(userId, doc) {                                                                                       // 3
		return userId === Meteor.userId();                                                                                  // 4
	}                                                                                                                    //
                                                                                                                      //
	function Update(userId, doc, fieldNames, modifier) {                                                                 // 7
		return userId === Meteor.userId();                                                                                  // 8
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 11
		onInsert: Insert,                                                                                                   // 12
		onUpdate: Update                                                                                                    // 13
	};                                                                                                                   //
}();                                                                                                                  //
                                                                                                                      //
Collections.MyBuildDisplay.allow({                                                                                    // 17
	insert: Controllers.MyBuildDisplayAllow.onInsert,                                                                    // 18
	update: Controllers.MyBuildDisplayAllow.onUpdate,                                                                    // 19
                                                                                                                      //
	remove: function () {                                                                                                // 21
		function remove() {                                                                                                 // 21
			return false;                                                                                                      // 22
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/myBuildDisplay/publish.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Meteor.publish('myBuildDisplay', function () {                                                                        // 2
	// TODO: Need to configure this to only show displayed when on dashboard.                                            //
	return Collections.MyBuildDisplay.find({ userId: this.userId });                                                     // 4
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"projects":{"controller.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/projects/controller.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/24/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Controllers.Projects = function () {                                                                                  // 6
	function _transform(doc) {                                                                                           // 7
		return new Models.Project(doc);                                                                                     // 8
	}                                                                                                                    //
                                                                                                                      //
	function GetAllByServerId(serverId) {                                                                                // 11
		return Collections.Projects.find({ serverId: serverId }, { transform: _transform });                                // 12
	}                                                                                                                    //
                                                                                                                      //
	function GetByServiceProjectId(serverId, serviceProjectId) {                                                         // 15
		return Collections.Projects.findOne({ serverId: serverId, serviceProjectId: serviceProjectId }, { transform: _transform });
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * @param {Models.Build} build                                                                                       //
  * @returns {*}                                                                                                      //
  * @constructor                                                                                                      //
  */                                                                                                                  //
	function AddBuild(build) {                                                                                           // 6
		return Collections.Builds.upsert({                                                                                  // 25
			serverId: build.serverId,                                                                                          // 26
			projectId: build.projectId,                                                                                        // 27
			serviceBuildId: build.serviceBuildId                                                                               // 28
		}, {                                                                                                                //
			$set: {                                                                                                            // 30
				name: build.name,                                                                                                 // 31
				href: build.href                                                                                                  // 32
			}                                                                                                                  //
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  *                                                                                                                   //
  * @param {Models.Project} project                                                                                   //
  * @param {Models.Build} builds[]                                                                                    //
  * @returns {*}                                                                                                      //
  * @constructor                                                                                                      //
  */                                                                                                                  //
	function AddProject(project, builds) {                                                                               // 6
		var parentId = null;                                                                                                // 45
		if (project.serviceParentProjectId) {                                                                               // 46
			var parentProject = Controllers.Projects.getByServiceProjectId(project.serverId, project.serviceParentProjectId);  // 47
			if (parentProject) {                                                                                               // 48
				parentId = parentProject._id;                                                                                     // 49
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		Collections.Projects.upsert({                                                                                       // 53
			serverId: project.serverId,                                                                                        // 54
			serviceProjectId: project.serviceProjectId                                                                         // 55
		}, {                                                                                                                //
			$set: {                                                                                                            // 57
				serviceParentProjectId: project.serviceParentProjectId,                                                           // 58
				parentId: parentId,                                                                                               // 59
				name: project.name,                                                                                               // 60
				href: project.href                                                                                                // 61
			}                                                                                                                  //
		});                                                                                                                 //
                                                                                                                      //
		var existingProj = Controllers.Projects.getByServiceProjectId(project.serverId, project.serviceProjectId);          // 65
                                                                                                                      //
		builds.forEach(function (build) {                                                                                   // 67
			build.projectId = existingProj._id;                                                                                // 68
			AddBuild(build);                                                                                                   // 69
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	function RemoveByServerId(serverId) {                                                                                // 73
		Collections.Projects.remove({ serverId: serverId });                                                                // 74
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 77
		getAllByServerId: GetAllByServerId,                                                                                 // 78
		getByServiceProjectId: GetByServiceProjectId,                                                                       // 79
		onAddProject: AddProject,                                                                                           // 80
		onRemoveByServerId: RemoveByServerId                                                                                // 81
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"projects.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/projects/projects.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/26/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
//Meteor.methods({                                                                                                    //
//                                                                                                                    //
//});                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/projects/publish.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by imod on 4/28/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Meteor.publish('projects', function () {                                                                              // 6
  return Collections.Projects.find({});                                                                               // 7
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"servers":{"controller.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/servers/controller.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Controllers.Servers = function () {                                                                                   // 2
	function _validateUser() {                                                                                           // 3
		if (!Meteor.user().isAdmin) {                                                                                       // 4
			throw new Meteor.Error(403, 'You are not authorized for this change.');                                            // 5
		}                                                                                                                   //
                                                                                                                      //
		return true;                                                                                                        // 8
	}                                                                                                                    //
                                                                                                                      //
	function _cleanUnamePWord(uname, pword) {                                                                            // 11
		var user = s.isBlank(uname) ? false : uname,                                                                        // 12
		    password = s.isBlank(pword) ? false : pword;                                                                    //
                                                                                                                      //
		return { user: user, password: password };                                                                          // 15
	}                                                                                                                    //
                                                                                                                      //
	function _transform(doc) {                                                                                           // 18
		return new Models.Server(doc);                                                                                      // 19
	}                                                                                                                    //
                                                                                                                      //
	function GetServer(serverId) {                                                                                       // 22
		return Collections.Servers.findOne({ _id: serverId }, { transform: _transform });                                   // 23
	}                                                                                                                    //
                                                                                                                      //
	function GetServerByName(name) {                                                                                     // 26
		return Collections.Servers.findOne({ name: name }, { transform: _transform });                                      // 27
	}                                                                                                                    //
                                                                                                                      //
	function GetServers() {                                                                                              // 30
		return Collections.Servers.find({}, { transform: _transform });                                                     // 31
	}                                                                                                                    //
                                                                                                                      //
	function SaveServer(id, name, url, uname, pword) {                                                                   // 34
		_validateUser();                                                                                                    // 35
                                                                                                                      //
		if (!name || !url) {                                                                                                // 37
			throw new Meteor.Error(500, 'Missing required field');                                                             // 38
		}                                                                                                                   //
                                                                                                                      //
		var up = _cleanUnamePWord(uname, pword);                                                                            // 41
                                                                                                                      //
		var server = new Models.Server({                                                                                    // 43
			_id: id,                                                                                                           // 44
			name: name,                                                                                                        // 45
			type: 'teamcity',                                                                                                  // 46
			url: url,                                                                                                          // 47
			user: up.user,                                                                                                     // 48
			password: up.password                                                                                              // 49
		});                                                                                                                 //
		return server.save();                                                                                               // 51
	}                                                                                                                    //
                                                                                                                      //
	function DeleteServer(id) {                                                                                          // 54
		_validateUser();                                                                                                    // 55
                                                                                                                      //
		Controllers.Projects.onRemoveByServerId(id);                                                                        // 57
		Controllers.Builds.onRemoveByServerId(id);                                                                          // 58
		Collections.Servers.remove({ _id: id });                                                                            // 59
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * @return {boolean}                                                                                                 //
  */                                                                                                                  //
	function RefreshProjects(serverId) {                                                                                 // 2
		console.log('Refreshing projects: ' + serverId);                                                                    // 66
		var server = Controllers.Servers.getServer(serverId);                                                               // 67
		server.refreshProjects();                                                                                           // 68
	}                                                                                                                    //
                                                                                                                      //
	function WatchBuild(serverId, buildId, userId, isWatch) {                                                            // 71
		var server = Controllers.Servers.getServer(serverId);                                                               // 72
		server.toggleBuildDisplay(buildId, userId, isWatch);                                                                // 73
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 76
		getServer: GetServer,                                                                                               // 77
		getServerByName: GetServerByName,                                                                                   // 78
		getServers: GetServers,                                                                                             // 79
                                                                                                                      //
		onSaveServer: SaveServer,                                                                                           // 81
		onDeleteServer: DeleteServer,                                                                                       // 82
		onRefreshProjects: RefreshProjects,                                                                                 // 83
                                                                                                                      //
		onWatchBuild: WatchBuild                                                                                            // 85
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/servers/publish.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/23/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Meteor.publish('servers', function () {                                                                               // 6
	var user = Meteor.users.findOne({ _id: this.userId }, { fields: { isAdmin: 1 } });                                   // 7
                                                                                                                      //
	if (!user || !user.isAdmin) {                                                                                        // 9
		return this.ready();                                                                                                // 10
	}                                                                                                                    //
                                                                                                                      //
	return Collections.Servers.find({});                                                                                 // 13
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"servers.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/servers/servers.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/23/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Collections.Servers.allow({                                                                                           // 6
	insert: function () {                                                                                                // 7
		function insert() {                                                                                                 // 7
			return false;                                                                                                      // 8
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 10
		function update() {                                                                                                 // 10
			return false;                                                                                                      // 11
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 13
		function remove() {                                                                                                 // 13
			return false;                                                                                                      // 14
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
Meteor.methods({                                                                                                      // 18
	insertServer: Controllers.Servers.onSaveServer,                                                                      // 19
	updateServer: Controllers.Servers.onSaveServer,                                                                      // 20
	deleteServer: Controllers.Servers.onDeleteServer,                                                                    // 21
                                                                                                                      //
	refreshProjects: Controllers.Servers.onRefreshProjects,                                                              // 23
	watchBuild: Controllers.Servers.onWatchBuild                                                                         // 24
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"services":{"factory.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/services/factory.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/26/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Services.Factory = function () {                                                                                      // 6
	function GetService(server) {                                                                                        // 7
		switch (server.type) {                                                                                              // 8
			case 'teamcity':                                                                                                   // 9
				{                                                                                                                 // 9
					return new Services.TeamCity(server, false /*s(server.url).contains('example.com')*/);                           // 10
				}break;                                                                                                           //
                                                                                                                      //
			default:                                                                                                           // 8
				{                                                                                                                 // 13
					throw 'Invalid server type: ' + server.type;                                                                     // 14
				}                                                                                                                 //
		}                                                                                                                   // 8
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 19
		getService: GetService                                                                                              // 20
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"teamcity.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/services/teamcity.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Services.TeamCity = function (server, isTest) {                                                                       // 3
	this.server = server;                                                                                                // 4
	this.isTest = isTest === true;                                                                                       // 5
};                                                                                                                    //
                                                                                                                      //
Services.TeamCity.prototype = {                                                                                       // 8
	//region Properties                                                                                                  //
	get hasAuth() {                                                                                                      // 10
		if (!this.server.user || !this.server.password) {                                                                   // 11
			return false;                                                                                                      // 12
		}                                                                                                                   //
                                                                                                                      //
		return true;                                                                                                        // 15
	},                                                                                                                   //
	//endregion                                                                                                          //
                                                                                                                      //
	//region Methods                                                                                                     //
	_buildOptions: function () {                                                                                         // 20
		function _buildOptions() {                                                                                          // 20
			var opt = {                                                                                                        // 21
				timeOut: 30000,                                                                                                   // 22
				headers: {                                                                                                        // 23
					'Accept': 'application/json'                                                                                     // 24
				}                                                                                                                 //
			};                                                                                                                 //
                                                                                                                      //
			if (this.hasAuth) {                                                                                                // 28
				opt.auth = this.server.user + ':' + this.server.password;                                                         // 29
			}                                                                                                                  //
                                                                                                                      //
			return opt;                                                                                                        // 32
		}                                                                                                                   //
                                                                                                                      //
		return _buildOptions;                                                                                               //
	}(),                                                                                                                 //
                                                                                                                      //
	_call: function () {                                                                                                 // 35
		function _call(url, callback) {                                                                                     // 35
			var opt = this._buildOptions(),                                                                                    // 36
			    fullUrl = this.server.url;                                                                                     //
                                                                                                                      //
			if (url.indexOf('/httpAuth/') === -1 && url.indexOf('/guestAuth/') === -1) {                                       // 39
				if (this.hasAuth) {                                                                                               // 40
					fullUrl += '/httpAuth';                                                                                          // 41
				} else {                                                                                                          //
					fullUrl += '/guestAuth';                                                                                         // 43
				}                                                                                                                 //
			}                                                                                                                  //
                                                                                                                      //
			fullUrl += url;                                                                                                    // 47
                                                                                                                      //
			console.log('Calling: ' + fullUrl);                                                                                // 49
			HTTP.get(fullUrl, opt, function (err, response) {                                                                  // 50
				if (err) {                                                                                                        // 51
					throw err;                                                                                                       // 52
				}                                                                                                                 //
                                                                                                                      //
				if (response.statusCode !== 200) {                                                                                // 55
					throw 'Call was not successful. Status code: ' + response.statusCode;                                            // 56
				}                                                                                                                 //
                                                                                                                      //
				callback(response.data);                                                                                          // 59
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return _call;                                                                                                       //
	}(),                                                                                                                 //
                                                                                                                      //
	_tcDateTimeToDate: function () {                                                                                     // 63
		function _tcDateTimeToDate(datetime) {                                                                              // 63
			if (!datetime) {                                                                                                   // 64
				return null;                                                                                                      // 65
			}                                                                                                                  //
			return moment(datetime, 'YYYYMMDDTHHmmssZ').toDate();                                                              // 67
		}                                                                                                                   //
                                                                                                                      //
		return _tcDateTimeToDate;                                                                                           //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * If a build was auto-triggered because of a dependency, this will try to get that dependency detail.               //
  *                                                                                                                   //
  * @param buildDetail                                                                                                //
  * @param cb                                                                                                         //
  * @returns {*}                                                                                                      //
  * @private                                                                                                          //
  */                                                                                                                  //
	_getDependencyBuildDetails: function () {                                                                            // 78
		function _getDependencyBuildDetails(buildDetail, cb) {                                                              // 78
			var self = this,                                                                                                   // 79
			    snapshot = buildDetail['snapshot-dependencies'],                                                               //
			    artifact = buildDetail['artifact-dependencies'],                                                               //
			    href = false;                                                                                                  //
			if (snapshot && snapshot.count > 0) {                                                                              // 83
				href = snapshot.build[0].href;                                                                                    // 84
			} else if (artifact && artifact.count > 0) {                                                                       //
				href = artifact.build[0].href;                                                                                    // 86
			}                                                                                                                  //
			if (!href) {                                                                                                       // 88
				return self._createBuildDetails(buildDetail, [], cb);                                                             // 89
			}                                                                                                                  //
                                                                                                                      //
			self._call(href, function (depDetail) {                                                                            // 92
				var users = self._getUsersFromBuildDetail(depDetail);                                                             // 93
				self._createBuildDetails(buildDetail, users, cb);                                                                 // 94
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return _getDependencyBuildDetails;                                                                                  //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Builds the BuildDetails object and sends it to the callback.                                                      //
  *                                                                                                                   //
  * @param buildDetail                                                                                                //
  * @param users                                                                                                      //
  * @param cb                                                                                                         //
  * @private                                                                                                          //
  */                                                                                                                  //
	_createBuildDetails: function () {                                                                                   // 106
		function _createBuildDetails(buildDetail, users, cb) {                                                              // 106
			var self = this;                                                                                                   // 107
                                                                                                                      //
			var bh = new Models.BuildDetail({                                                                                  // 109
				id: buildDetail.id,                                                                                               // 110
				serviceBuildId: buildDetail.buildTypeId,                                                                          // 111
				serviceNumber: buildDetail.number,                                                                                // 112
				isSuccess: buildDetail.status === 'SUCCESS',                                                                      // 113
				isBuilding: buildDetail.running === true,                                                                         // 114
				href: buildDetail.href,                                                                                           // 115
				percentageComplete: buildDetail.percentageComplete,                                                               // 116
				statusText: buildDetail.statusText,                                                                               // 117
				startDate: self._tcDateTimeToDate(buildDetail.startDate),                                                         // 118
				finishDate: self._tcDateTimeToDate(buildDetail.finishDate),                                                       // 119
				usernames: users                                                                                                  // 120
			});                                                                                                                //
                                                                                                                      //
			cb(bh);                                                                                                            // 123
		}                                                                                                                   //
                                                                                                                      //
		return _createBuildDetails;                                                                                         //
	}(),                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the responsible user from a build detail.                                                                    //
  *                                                                                                                   //
  * @param buildDetail                                                                                                //
  * @returns {Array}                                                                                                  //
  * @private                                                                                                          //
  */                                                                                                                  //
	_getUsersFromBuildDetail: function () {                                                                              // 133
		function _getUsersFromBuildDetail(buildDetail) {                                                                    // 133
			var users = [];                                                                                                    // 134
			if (buildDetail.triggered) {                                                                                       // 135
				switch (buildDetail.triggered.type) {                                                                             // 136
					case 'buildType':                                                                                                // 137
						{}                                                                                                              // 138
						break;                                                                                                          // 141
					case 'user':                                                                                                     // 136
						{                                                                                                               // 143
							users = [buildDetail.triggered.user.username];                                                                 // 144
						}                                                                                                               //
						break;                                                                                                          // 146
                                                                                                                      //
					case 'vcs':                                                                                                      // 136
						{                                                                                                               // 149
							if (buildDetail.lastChanges.count > 0) {                                                                       // 150
								users = _.map(buildDetail.lastChanges.change, function (change) {                                             // 151
									return change.username;                                                                                      // 152
								});                                                                                                           //
							}                                                                                                              //
						}                                                                                                               //
						break;                                                                                                          // 156
				}                                                                                                                 // 136
			}                                                                                                                  //
                                                                                                                      //
			return users;                                                                                                      // 160
		}                                                                                                                   //
                                                                                                                      //
		return _getUsersFromBuildDetail;                                                                                    //
	}(),                                                                                                                 //
                                                                                                                      //
	getBuildData: function () {                                                                                          // 163
		function getBuildData(href, historyCount, cb) {                                                                     // 163
			var self = this;                                                                                                   // 164
                                                                                                                      //
			self._call(href + '/builds?count=' + historyCount, function (data) {                                               // 166
				var bhArray = [],                                                                                                 // 167
				    expectedCount = data.count;                                                                                   //
                                                                                                                      //
				for (var i = 0; i < expectedCount; i++) {                                                                         // 170
					var build = data.build[i];                                                                                       // 171
                                                                                                                      //
					self.getBuildDetails(build.href, function (bh) {                                                                 // 173
						bhArray.push(bh);                                                                                               // 174
                                                                                                                      //
						if (bhArray.length === expectedCount) {                                                                         // 176
							bhArray = _.sortBy(bhArray, function (item) {                                                                  // 177
								return item.id;                                                                                               // 178
							}).reverse();                                                                                                  //
							cb(bhArray);                                                                                                   // 180
						}                                                                                                               //
					});                                                                                                              //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return getBuildData;                                                                                                //
	}(),                                                                                                                 //
                                                                                                                      //
	getBuildDetails: function () {                                                                                       // 187
		function getBuildDetails(href, cb) {                                                                                // 187
			var self = this;                                                                                                   // 188
			self._call(href, function (buildDetail) {                                                                          // 189
				if (buildDetail.triggered && buildDetail.triggered.type === 'unknown') {                                          // 190
					return self._getDependencyBuildDetails(buildDetail, cb);                                                         // 191
				}                                                                                                                 //
                                                                                                                      //
				var users = self._getUsersFromBuildDetail(buildDetail);                                                           // 194
				self._createBuildDetails(buildDetail, users, cb);                                                                 // 195
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return getBuildDetails;                                                                                             //
	}(),                                                                                                                 //
                                                                                                                      //
	queryRunningBuilds: function () {                                                                                    // 199
		function queryRunningBuilds(cb) {                                                                                   // 199
			var self = this;                                                                                                   // 200
			self._call('/app/rest/builds?locator=running:true', function (buildSummary) {                                      // 201
				var bsArr = [];                                                                                                   // 202
                                                                                                                      //
				if (buildSummary.count === 0) {                                                                                   // 204
					return cb(bsArr);                                                                                                // 205
				}                                                                                                                 //
                                                                                                                      //
				buildSummary.build.forEach(function (build) {                                                                     // 208
					bsArr.push(new Models.BuildSummary({                                                                             // 209
						id: build.id,                                                                                                   // 210
						serviceBuildId: build.buildTypeId,                                                                              // 211
						serviceNumber: build.number,                                                                                    // 212
						isSuccess: build.status === 'SUCCESS',                                                                          // 213
						isBuilding: build.running === true,                                                                             // 214
						href: build.href                                                                                                // 215
					}));                                                                                                             //
				});                                                                                                               //
                                                                                                                      //
				cb(bsArr);                                                                                                        // 220
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return queryRunningBuilds;                                                                                          //
	}(),                                                                                                                 //
                                                                                                                      //
	getProjects: function () {                                                                                           // 224
		function getProjects(cb) {                                                                                          // 224
			var self = this;                                                                                                   // 225
                                                                                                                      //
			self._call('/app/rest/projects', function (tcProjects) {                                                           // 227
				if (!tcProjects) {                                                                                                // 228
					return;                                                                                                          // 229
				}                                                                                                                 //
                                                                                                                      //
				for (var i = 0; i < tcProjects.count; i++) {                                                                      // 232
					var project = tcProjects.project[i];                                                                             // 233
                                                                                                                      //
					if (project.id === '_Root') {                                                                                    // 235
						continue;                                                                                                       // 236
					}                                                                                                                //
                                                                                                                      //
					self._call(project.href, function (tcProject) {                                                                  // 239
						var proj = new Models.Project({                                                                                 // 240
							serverId: self.server._id,                                                                                     // 241
							serviceProjectId: tcProject.id,                                                                                // 242
							serviceParentProjectId: tcProject.parentProjectId === '_Root' ? null : tcProject.parentProjectId,              // 243
							name: tcProject.name,                                                                                          // 244
							href: tcProject.href                                                                                           // 245
						}),                                                                                                             //
						    builds = [];                                                                                                //
                                                                                                                      //
						if (tcProject.buildTypes && tcProject.buildTypes.count > 0) {                                                   // 249
							for (var ib = 0; ib < tcProject.buildTypes.count; ib++) {                                                      // 250
								var b = tcProject.buildTypes.buildType[ib],                                                                   // 251
								    build = new Models.Build({                                                                                //
									serverId: self.server._id,                                                                                   // 253
									serviceProjectId: b.projectId,                                                                               // 254
									serviceBuildId: b.id,                                                                                        // 255
									name: b.name,                                                                                                // 256
									href: b.href                                                                                                 // 257
								});                                                                                                           //
                                                                                                                      //
								builds.push(build);                                                                                           // 260
							}                                                                                                              //
						}                                                                                                               //
                                                                                                                      //
						cb(proj, builds);                                                                                               // 264
					});                                                                                                              //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return getProjects;                                                                                                 //
	}()                                                                                                                  //
                                                                                                                      //
	//endregion                                                                                                          //
};                                                                                                                    // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"controller.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/users/controller.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/23/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Controllers.Users = function () {                                                                                     // 6
	function CreateUser(options, user) {                                                                                 // 7
		if (!options || !user || !options.email) {                                                                          // 8
			throw new Meteor.Error(500, 'Invalid input!');                                                                     // 9
		}                                                                                                                   //
                                                                                                                      //
		if (!Meteor.users.findOne()) {                                                                                      // 12
			user.isAdmin = true;                                                                                               // 13
		}                                                                                                                   //
                                                                                                                      //
		if (!user.isAdmin) {                                                                                                // 16
			if (Meteor.users.findOne({ 'emails.0.address': options.email })) {                                                 // 17
				throw new Meteor.Error(500, 'Email already exists');                                                              // 18
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return user;                                                                                                        // 22
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 25
		onCreateUser: CreateUser                                                                                            // 26
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/users/publish.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by imod on 4/24/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Meteor.publish('myUser', function () {                                                                                // 6
  return Meteor.users.find({ _id: this.userId }, { fields: { isAdmin: 1, username: 1, profile: 1 } });                // 7
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/users/users.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by paul on 4/23/15.                                                                                        //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
Meteor.users.allow({                                                                                                  // 6
	insert: function () {                                                                                                // 7
		function insert() {                                                                                                 // 7
			return false;                                                                                                      // 8
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
                                                                                                                      //
	update: function () {                                                                                                // 11
		function update() {                                                                                                 // 11
			return false;                                                                                                      // 12
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 14
		function remove() {                                                                                                 // 14
			return false;                                                                                                      // 15
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
Accounts.onCreateUser(Controllers.Users.onCreateUser);                                                                // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"timerController.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/timerController.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Created by imod on 5/8/15.                                                                                         //
 */                                                                                                                   //
                                                                                                                      //
'use strict';                                                                                                         // 5
                                                                                                                      //
// TODO: This won't work too well if we have multiple server instances.                                               //
// TODO: Add a configuration option to indicate if this is the main server instance, or...                            //
// TODO: Create a second server only app / node server that just the timers.                                          //
                                                                                                                      //
var RUNNING_BUILD_QUERY_MS = 20000,                                                                                   // 12
    CURRENT_BUILD_STATUS_QUERY_MS = 5000;                                                                             //
                                                                                                                      //
Controllers.Timer = function () {                                                                                     // 15
	var buildQueryHandle = false,                                                                                        // 16
	    currentBuildServerTimerHandles = [];                                                                             //
                                                                                                                      //
	function StartRunningBuildsTimer(serverId) {                                                                         // 19
		if (!process.env.IS_MIRROR) {                                                                                       // 20
			console.log('Starting running build timer for server: ' + serverId);                                               // 21
                                                                                                                      //
			var id = Meteor.setInterval(function () {                                                                          // 23
				Controllers.Timer.onRunningBuildQueryInterval(serverId);                                                          // 24
			}, CURRENT_BUILD_STATUS_QUERY_MS);                                                                                 //
                                                                                                                      //
			currentBuildServerTimerHandles.push({ serverId: serverId, timerId: id });                                          // 27
		}                                                                                                                   //
	}                                                                                                                    //
                                                                                                                      //
	function StopRunningBuildsTimer(serverId) {                                                                          // 31
		console.log('Stopping running build timer for server: ' + serverId);                                                // 32
		var serverTimerHandle = _.find(currentBuildServerTimerHandles, function (s) {                                       // 33
			return s.serverId === serverId;                                                                                    // 34
		});                                                                                                                 //
                                                                                                                      //
		Meteor.clearInterval(serverTimerHandle.timerId);                                                                    // 37
		currentBuildServerTimerHandles = _.reject(currentBuildServerTimerHandles, function (s) {                            // 38
			return s.serverId === serverTimerHandle.serverId;                                                                  // 39
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	function CheckRunningBuildsTimer(serverId, hasActiveBuilds) {                                                        // 43
		var serverTimerHandle = _.find(currentBuildServerTimerHandles, function (s) {                                       // 44
			return s.serverId === serverId;                                                                                    // 45
		});                                                                                                                 //
                                                                                                                      //
		if (hasActiveBuilds && !serverTimerHandle) {                                                                        // 48
			Controllers.Timer.onStartRunningBuildsTimer(serverId);                                                             // 49
		} else if (!hasActiveBuilds && serverTimerHandle) {                                                                 //
			Controllers.Timer.onStopRunningBuildsTimer(serverId);                                                              // 51
		}                                                                                                                   //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * This will be called every CURRENT_BUILD_STATUS_QUERY_MS to update the status                                      //
  * of the running builds.                                                                                            //
  *                                                                                                                   //
  * @param serverId                                                                                                   //
  * @constructor                                                                                                      //
  */                                                                                                                  //
	function RunningBuildQueryInterval(serverId) {                                                                       // 15
		console.log('Running build timer for server: ' + serverId);                                                         // 64
                                                                                                                      //
		var server = Controllers.Servers.getServer(serverId);                                                               // 66
		server.updateRunningBuilds(CheckRunningBuildsTimer);                                                                // 67
	}                                                                                                                    //
                                                                                                                      //
	function PollInterval() {                                                                                            // 70
		var servers = Controllers.Servers.getServers();                                                                     // 71
		servers.forEach(function (server) {                                                                                 // 72
			server.queryRunningBuilds(CheckRunningBuildsTimer);                                                                // 73
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	function Startup() {                                                                                                 // 77
		if (buildQueryHandle !== false) {                                                                                   // 78
			Meteor.clearTimeout(buildQueryHandle);                                                                             // 79
			buildQueryHandle = false;                                                                                          // 80
		}                                                                                                                   //
                                                                                                                      //
		if (!process.env.IS_MIRROR) {                                                                                       // 83
			buildQueryHandle = Meteor.setInterval(PollInterval, RUNNING_BUILD_QUERY_MS);                                       // 84
		}                                                                                                                   //
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 88
		onStartUp: Startup,                                                                                                 // 89
		onStartRunningBuildsTimer: StartRunningBuildsTimer,                                                                 // 90
		onStopRunningBuildsTimer: StopRunningBuildsTimer,                                                                   // 91
		onRunningBuildQueryInterval: RunningBuildQueryInterval,                                                             // 92
		onCheckRunningBuildsTimer: CheckRunningBuildsTimer,                                                                 // 93
		onPollInterval: PollInterval                                                                                        // 94
	};                                                                                                                   //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      //
Controllers.main = function () {                                                                                      // 2
                                                                                                                      //
	function RefreshActiveBuilds() {                                                                                     // 4
		var servers = Controllers.Servers.getServers();                                                                     // 5
                                                                                                                      //
		servers.forEach(function (server) {                                                                                 // 7
			server.refreshActiveBuildData();                                                                                   // 8
		});                                                                                                                 //
	}                                                                                                                    //
                                                                                                                      //
	return {                                                                                                             // 12
		onRefreshActiveBuilds: RefreshActiveBuilds                                                                          // 13
	};                                                                                                                   //
}();                                                                                                                  //
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 17
	Controllers.main.onRefreshActiveBuilds();                                                                            // 18
	Controllers.Timer.onStartUp();                                                                                       // 19
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/ext/bower_components/underscore.string/underscore.string.js");
require("./lib/_namespace/_namespaces.js");
require("./server/lib/_namespaces.js");
require("./server/builds/!controller.js");
require("./server/builds/builds.js");
require("./server/builds/publish.js");
require("./server/models/build.js");
require("./server/models/buildDetail.js");
require("./server/models/buildSummary.js");
require("./server/models/project.js");
require("./server/models/server.js");
require("./server/models/username.js");
require("./server/myBuildDisplay/controller.js");
require("./server/myBuildDisplay/myBuildDisplay.js");
require("./server/myBuildDisplay/publish.js");
require("./server/projects/controller.js");
require("./server/projects/projects.js");
require("./server/projects/publish.js");
require("./server/servers/controller.js");
require("./server/servers/publish.js");
require("./server/servers/servers.js");
require("./server/services/factory.js");
require("./server/services/teamcity.js");
require("./server/users/controller.js");
require("./server/users/publish.js");
require("./server/users/users.js");
require("./server/timerController.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
