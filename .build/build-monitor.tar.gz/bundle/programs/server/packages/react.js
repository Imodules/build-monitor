(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/react/react.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// Write your package code here!

///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.react = {};

})();

//# sourceMappingURL=react.js.map
