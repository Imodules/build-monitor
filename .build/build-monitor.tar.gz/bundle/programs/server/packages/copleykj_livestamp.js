(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var livestamp;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/copleykj_livestamp/packages/copleykj_livestamp.js        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['copleykj:livestamp'] = {
  livestamp: livestamp
};

})();

//# sourceMappingURL=copleykj_livestamp.js.map
